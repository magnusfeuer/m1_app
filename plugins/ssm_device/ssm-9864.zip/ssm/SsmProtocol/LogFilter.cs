///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// LogFilter.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace NateW.Ssm
{
    /// <summary>
    /// Creates LogWriters on demand
    /// </summary>
    /// <returns>an instance of LogWriter</returns>
    public delegate LogWriter LogWriterFactory();

    /// <summary>
    /// Determines what's worth logging
    /// </summary>
    /// <returns>true if the row should be logged, false if not</returns>
    public delegate bool LogFilterPredicate(LogRow row);

    /// <summary>
    /// Writes logs only when specified conditions are met
    /// </summary>
    /// <remarks>This is the key thing for defogger-controlled logging.</remarks>
    public class LogFilter
    {
        /// <summary>
        /// Creates LogWriters on demand
        /// </summary>
        private LogWriterFactory factory;

        /// <summary>
        /// Determines what's worth logging
        /// </summary>
        private LogFilterPredicate predicate;

        /// <summary>
        /// Writes logs
        /// </summary>
        private LogWriter writer;

        /// <summary>
        /// Private constructor.  Use the factory method instead
        /// </summary>
        private LogFilter(
            LogWriterFactory factory, 
            LogFilterPredicate predicate)
        {
            this.factory = factory;
            this.predicate = predicate;
        }

        /// <summary>
        /// Factory
        /// </summary>
        /// <param name="factory">Creates LogWriters on-demand</param>
        /// <param name="predicate">Decides what's worth logging and what isn't</param>
        /// <returns>an instance of LogFilter</returns>
        public static LogFilter GetInstance(
            LogWriterFactory factory, 
            LogFilterPredicate predicate)
        {
            return new LogFilter(factory, predicate);
        }

        /// <summary>
        /// Write the names of the colums
        /// </summary>
        /// <param name="row">collection of columns, values, and conversions</param>
        public void LogStart(LogRow row)
        {
            this.ManageWriterState(row);
        }

        /// <summary>
        /// Write values from the given log entry to the stream
        /// </summary>
        /// <param name="row">collection of columns, values, and conversions</param>
        public void LogEntry(LogRow row)
        {
            if (this.ManageWriterState(row))
            {
                this.writer.LogEntry(row);
            }
        }

        /// <summary>
        /// Flush the writer
        /// </summary>
        public void LogStop()
        {
            this.SafelyDisposeWriter();
        }

        /// <summary>
        /// Create and dispose log writer as necessary
        /// </summary>
        /// <param name="row">row of data from the SSM interface</param>
        /// <returns>true if </returns>
        private bool ManageWriterState(LogRow row)
        {
            if (this.predicate(row))
            {
                if (this.writer == null)
                {
                    this.writer = this.factory();
                    this.writer.LogStart(row);
                }
                return true;
            }
            else
            {
                this.SafelyDisposeWriter();
                return false;
            }
        }

        /// <summary>
        /// Stop and dispose the writer, if there is one
        /// </summary>
        private void SafelyDisposeWriter()
        {
            if (this.writer != null)
            {
                this.writer.LogStop();
                this.writer.Dispose();
                this.writer = null;
            }
        }
    }
}
