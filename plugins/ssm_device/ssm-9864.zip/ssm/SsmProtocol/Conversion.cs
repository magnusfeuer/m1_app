///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// Conversion.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using EB.Math;

namespace NateW.Ssm
{
    /// <summary>
    /// Converts values to strings suitable for display
    /// </summary>
    public class Conversion
    {
        /// <summary>
        /// Default conversion if none found in logger.xml
        /// </summary>
        public readonly static Conversion Raw = new Conversion("raw", "x", "0.00");

        /// <summary>
        /// 'Units' string for boolean parameters (aka switches)
        /// </summary>
        public const string Boolean = "boolean";

        /// <summary>
        /// Units the conversion yeilds
        /// </summary>
        private string units;

        /// <summary>
        /// String containing the mathematical expression for the conversion
        /// </summary>
        private string expression;

        /// <summary>
        /// Format to use for display of the value
        /// </summary>
        private string format;

        /// <summary>
        /// Function that executes the expression
        /// </summary>
        private Function function;

        /// <summary>
        /// Units the conversion yeilds
        /// </summary>
        public string Units
        {
            [DebuggerStepThrough()] 
            get { return units; }
        }

        /// <summary>
        /// String containing the mathematical expression for the conversion
        /// </summary>
        public string Expression 
        {
            [DebuggerStepThrough()]
            get { return expression; }
        }

        /// <summary>
        /// Format to use for display of the value
        /// </summary>
        public string Format 
        {
            [DebuggerStepThrough()]
            get { return format; }
        }

        /// <summary>
        /// Constructor (private, use factory instead)
        /// </summary>
        private Conversion(string units, string expression, string format)
        {
            this.units = units;
            this.expression = expression;
            this.format = "{0:" + format + "}";
        }

        /// <summary>
        /// For display in debugger, do not use in UI
        /// </summary>
        [DebuggerStepThrough()]
        public override string ToString()
        {
            return this.units + " (" + this.format + ")";
        }

        /// <summary>
        /// Factory
        /// </summary>
        public static Conversion GetInstance(string units, string expression, string format)
        {
            return new Conversion(units, expression, format);
        }

        /// <summary>
        /// Convert and format the given value 
        /// </summary>
        public string Convert(double d)
        {
            if (this.function == null)
            {
                this.function = new Function();
                function.Parse(this.expression);
                function.Infix2Postfix();
            }

            ArrayList var = function.Variables;
            Symbol symbol = (Symbol)var[0];
            symbol.m_value = d;
            var[0] = symbol;
            function.Variables = var;
            function.EvaluatePostfix();
            double nResult = function.Result;
            string result;

            if (this.units == Conversion.Boolean)
            {
                if (nResult == 0)
                {
                    result = false.ToString();
                }
                else
                {
                    result = true.ToString();
                }
            }
            else
            {
                result = string.Format(format, nResult);
            }

            return result;
        }
        
        /// <summary>
        /// Combine and convert the values in the dependent columns
        /// </summary>
        public string Convert(Dictionary<string, LogColumn> dependencyMap)
        {
            if (this.function == null)
            {
                this.function = new Function();
                function.Parse(this.expression);
                function.Infix2Postfix();
            }

            ArrayList var = function.Variables;
            foreach (Symbol symbol in var)
            {
                string s = dependencyMap[symbol.m_name].Value;
                double d = double.Parse(s);
                symbol.m_value = d;
            }
            function.Variables = var;

            function.EvaluatePostfix();
            double nResult = function.Result;
            string result = string.Format(format, nResult);
            return result;
        }
    }
}
