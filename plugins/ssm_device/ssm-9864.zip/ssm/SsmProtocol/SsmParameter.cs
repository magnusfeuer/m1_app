///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// SsmParameter.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Text;

namespace NateW.Ssm
{
    /// <summary>
    /// Describes a parameter in the SSM database
    /// </summary>
    public class SsmParameter
    {
        /// <summary>
        /// Parameter ID
        /// </summary>
        private string id;

        /// <summary>
        /// Display name
        /// </summary>
        private string name;

        /// <summary>
        /// Address to read
        /// </summary>
        private UInt32 address;

        /// <summary>
        /// Number of bytes to read
        /// </summary>
        private int length;

        /// <summary>
        /// Conversions available to render the parameter value
        /// </summary>
        private IList<Conversion> conversions;

        /// <summary>
        /// Byte in the ECU capability vector that indicates whether this parameter is supported
        /// </summary>
        private int ecuCapabilityByteIndex;

        /// <summary>
        /// Bit in the ECU capability vector that indicates whether this parameter is supported
        /// </summary>
        private int ecuCapabilityBitIndex;

        /// <summary>
        /// Parameters that this parameter is calculated from
        /// </summary>
        private ReadOnlyCollection<SsmParameter> dependencies;

        /// <summary>
        /// Parameter ID
        /// </summary>
        public string Id
        {
            [DebuggerStepThrough()]
            get { return this.id; }
        }

        /// <summary>
        /// Display name
        /// </summary>
        public string Name
        {
            [DebuggerStepThrough()]
            get { return this.name; }
        }

        /// <summary>
        /// If true, the parameter's value is calculated from other parameters
        /// </summary>
        public bool IsCalculated
        {
            [DebuggerStepThrough()]
            get { return (this.dependencies != null); }
        }

        /// <summary>
        /// Address to read
        /// </summary>
        public UInt32 Address
        {
            [DebuggerStepThrough()]
            get 
            {
                if (this.dependencies != null)
                {
                    throw new InvalidOperationException("This is a calculated parameter, it has no address.");
                }
                return this.address;
            }

            [DebuggerStepThrough()]
            internal set { this.address = value; }
        }

        /// <summary>
        /// Number of bytes to read
        /// </summary>
        public int Length 
        {
            [DebuggerStepThrough()]
            get { return this.length; }
        }

        /// <summary>
        /// Conversions available to render the parameter value
        /// </summary>
        public IList<Conversion> Conversions 
        {
            [DebuggerStepThrough()]
            get { return this.conversions; }
        }

        /// <summary>
        /// Byte in the ECU capability vector that indicates whether this parameter is supported
        /// </summary>
        public int EcuCapabilityByteIndex
        {
            [DebuggerStepThrough()]
            get { return this.ecuCapabilityByteIndex; }
        }

        /// <summary>
        /// Bit in the ECU capability vector that indicates whether this parameter is supported
        /// </summary>
        public int EcuCapabilityBitIndex 
        {
            [DebuggerStepThrough()]
            get { return this.ecuCapabilityBitIndex; }
        }

        /// <summary>
        /// Parameters that this parameter is calculated from
        /// </summary>
        public ReadOnlyCollection<SsmParameter> Dependencies 
        {
            [DebuggerStepThrough()]
            get { return this.dependencies; }
        }

        /// <summary>
        /// Constructor for extended parameters
        /// </summary>
        public SsmParameter(
            string id,
            string name,
            UInt32 address,
            int length,
            IList<Conversion> conversions)
            :
            this(
                id,
                name,
                address,
                length,
                conversions,
                0,
                0,
                null)
        {
        }
                
        /// <summary>
        /// Constructor for basic parameters
        /// </summary>
        public SsmParameter(
            string id,
            string name,
            UInt32 address,
            int length,
            IList<Conversion> conversions,
            int ecuCapabilityByteIndex,
            int ecuCapabilityBitIndex,
            ReadOnlyCollection<SsmParameter> dependencies)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.length = length;
            this.conversions = conversions;
            this.ecuCapabilityByteIndex = ecuCapabilityByteIndex;
            this.ecuCapabilityBitIndex = ecuCapabilityBitIndex;
            this.dependencies = dependencies;
        }

        /// <summary>
        /// For debugger only - do not surface this in the UI
        /// </summary>
        /// <returns></returns>
        [DebuggerStepThrough()]
        public override string ToString()
        {
            return this.name;
        }

        /// <summary>
        /// Get a Conversion with the given units
        /// </summary>
        public bool TryGetConversionByUnits(string units, out Conversion conversion)
        {
            foreach (Conversion candidate in this.conversions)
            {
                if (candidate.Units == units)
                {
                    conversion = candidate;
                    return true;
                }
            }
            conversion = null;
            return false;
        }

        /// <summary>
        /// Checks for matching IDs
        /// </summary>
        /// <remarks>
        /// Only here to support checking for duplicates in the parameter database
        /// </remarks>
        public override bool Equals(object obj)
        {
            SsmParameter that = obj as SsmParameter;
            if (that == null)
            {
                return false;
            }
            return this.id == that.id;
        }

        /// <summary>
        /// Get has code
        /// </summary>
        /// <remarks>
        /// Only here to suppress warning that happens after you override Equals
        /// </remarks>
        public override int GetHashCode()
        {
            return this.id.GetHashCode();
        }
    }
}