///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// SsmLogger.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.IO;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Text;
using System.Xml.Serialization;

namespace NateW.Ssm
{
    /// <summary>
    /// EventArgs sent when starting a log and when each log row is received
    /// </summary>
    public class LogEventArgs : System.EventArgs
    {
        private LogRow row;

        public LogRow Row
        {
            [DebuggerStepThrough()]
            get { return this.row; }
        }

        public LogEventArgs(LogRow row)
        {
            this.row = row;
        }
    }

    /// <summary>
    /// EventArgs sent when an error interrupts logging
    /// </summary>
    public class LogErrorEventArgs
    {        /// <summary>
        /// Exception
        /// </summary>
        private Exception exception;

        /// <summary>
        /// Event handler can set this to true if the exception was handled
        /// </summary>
        private bool shouldContinue = false;

        /// <summary>
        /// The Exception thrown by the logging operation
        /// </summary>
        public Exception Exception
        {
            [DebuggerStepThrough()]
            get { return this.exception; }
        }

        /// <summary>
        /// Event handler can set this to true if the exception was handled
        /// </summary>
        public bool ShouldContinue
        {
            [DebuggerStepThrough()]
            internal get { return this.shouldContinue; }
            [DebuggerStepThrough()]
            set { this.shouldContinue = value; }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        internal LogErrorEventArgs(Exception exception)
        {
            this.exception = exception;
        }
    }

    /// <summary>
    /// AsyncResult for the SsmLogger.Connect operation
    /// </summary>
    internal class ConnectAsyncResult : AsyncResult
    {
        public ConnectAsyncResult(AsyncCallback asyncCallback, object asyncState) :
            base (asyncCallback, asyncState)
        {
        }
    }

    public delegate void LogStartEventHandler(object sender, LogEventArgs args);
    public delegate void LogEntryEventHandler(object sender, LogEventArgs args);
    public delegate void LogStopEventHandler(object sender, EventArgs args);
    public delegate void LogErrorEventHandler(object sender, LogErrorEventArgs args);

    /// <summary>
    /// Application-facing API for logging with SSM
    /// </summary>
    /// <remarks>
    /// Encapsulates the SSM protocol and parameter database,
    /// and takes care of logging start/stop logic.
    /// </remarks>
    public class SsmLogger
    {
        /// <summary>
        /// Filter string for Open and Save file dialogs
        /// </summary>
        public static readonly string FileDialogFilterString = string.Format(
                    "Profiles (*{0})|*{0}|All Files (*.*)|*.*", 
                    SsmLogger.DefaultProfileExtension, 
                    SsmLogger.DefaultProfileExtension);

        /// <summary>
        /// Default extension to use for logger profile files
        /// </summary>
        public const string DefaultProfileExtension = ".profile";

        /// <summary>
        /// Identifies the ECU the logger is talking to
        /// </summary>
        private SsmInterface ecu;

        /// <summary>
        /// Directory with logger.xml
        /// </summary>
        private string configurationDirectory;

        /// <summary>
        /// Describes all parameters supported by the ECU
        /// </summary>
        private SsmParameterDatabase database;

        /// <summary>
        /// Holds the public LogProfile and the associated event args, addresses, raw data, etc
        /// </summary>
        private InternalLogProfile internalProfile;

        /// <summary>
        /// If true, logging is active
        /// </summary>
        private bool isLogging;

        /// <summary>
        /// Invoked when logging begins - handler can open the CSV file and write the header
        /// </summary>
        public event LogStartEventHandler LogStart;

        /// <summary>
        /// Invoked when a log row is available - handler can write a line to the CSV file
        /// </summary>
        public event LogEntryEventHandler LogEntry;

        /// <summary>
        /// Invoked when logging ends - handler can close the CSV file
        /// </summary>
        public event LogStopEventHandler LogStop;

        /// <summary>
        /// Invoked when an error occures - handler may be able to recover by flushing the serial port's IO buffers
        /// </summary>
        public event LogErrorEventHandler LogError;

        /// <summary>
        /// Identifies the ECU the logger is talking to
        /// </summary>
        public string EcuIdentifier
        {
            get
            {
                if (this.ecu == null)
                {
                    throw new InvalidOperationException("Connect first.");
                }
                return this.ecu.EcuIdentifier;
            }
        }

        /// <summary>
        /// Describes all parameters supported by the current ECU
        /// </summary>
        public SsmParameterDatabase Database
        {
            [DebuggerStepThrough()]
            get { return this.database; }
        }

        /// <summary>
        /// Describes the parameters that are currently being logged
        /// </summary>
        public LogProfile CurrentProfile
        {
            [DebuggerStepThrough()]
            get { return this.internalProfile.LogProfile; }
        }

        /// <summary>
        /// Indicates whether the logger is logging now
        /// </summary>
        public bool IsLogging
        {
            [DebuggerStepThrough()]
            get { return this.isLogging; }
        }

        /// <summary>
        /// Addresses for the ECU query (for test use only)
        /// </summary>
        internal List<UInt32> Addresses
        {
            [DebuggerStepThrough()]
            get { return this.internalProfile.Addresses; }
        }

        /// <summary>
        /// Private constructor - use factory instead
        /// </summary>
        private SsmLogger(string configurationDirectory, Stream stream)
        {
            this.configurationDirectory = configurationDirectory;
            this.ecu = SsmInterface.GetInstance(stream);            
        }

        /// <summary>
        /// Factory
        /// </summary>
        public static SsmLogger GetInstance(string configurationDirectory, Stream stream)
        {
            SsmLogger instance = new SsmLogger(configurationDirectory, stream);
            return instance;
        }

        /// <summary>
        /// Begins an asyncrhonous operation to connect to the ECU, get the 
        /// ECU ID, and load the supported parameters from the database.
        /// </summary>
        public IAsyncResult BeginConnect(AsyncCallback callback, object state)
        {
            ConnectAsyncResult asyncResult = new ConnectAsyncResult(callback, state);
            this.ecu.BeginGetEcuIdentifier(GetEcuIdentifierCallback, asyncResult);
            return asyncResult;
        }

        /// <summary>
        /// Complete the BeginConnect asynchronous operation
        /// </summary>
        public void EndConnect(IAsyncResult asyncResult)
        {
            ConnectAsyncResult internalState = (ConnectAsyncResult)asyncResult;
            if (internalState.Exception != null)
            {
                throw internalState.Exception;
            }
        }

        /// <summary>
        /// Selects parameters to be logged
        /// </summary>
        public void SetProfile(LogProfile profile)
        {
            this.internalProfile = InternalLogProfile.GetInstance(profile, this.database);
        }

        /// <summary>
        /// Starts logging
        /// </summary>
        public void StartLogging()
        {
            if (this.isLogging)
            {
                throw new InvalidOperationException("Logging is already active.");
            }

            if (this.internalProfile.Addresses.Count == 0)
            {
                throw new InvalidOperationException("Logging profile is empty.");
            }

            if (this.LogStart != null)
            {
                this.LogStart(this, this.internalProfile.LogEventArgs);
            }

            this.isLogging = true;
            this.ecu.BeginMultipleRead(this.internalProfile.Addresses, EndMultipleReadCallback, this.internalProfile);
        }

        /// <summary>
        /// Stops logging
        /// </summary>
        public void StopLogging()
        {
            this.isLogging = false;

            while (this.ecu.OperationInProgress)
            {
                System.Threading.Thread.Sleep(100);
            }
        }
                
        /// <summary>
        /// Save the current profile to the given path
        /// </summary>
        public void SaveProfile(string path)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(SerializedColumn[]));
            using (Stream stream = File.OpenWrite(path))
            {
                stream.SetLength(0);
                List<SerializedColumn> columns = new List<SerializedColumn>(this.internalProfile.LogEventArgs.Row.Columns.Count);
                foreach (LogColumn column in this.internalProfile.LogEventArgs.Row.Columns)
                {
                    if (!column.IsDependency)
                    {
                        columns.Add(
                            new SerializedColumn(
                                column.Parameter.Id,
                                column.Parameter.Name,
                                column.Conversion.Units));
                    }
                }
                serializer.Serialize(stream, columns.ToArray());
            }
        }

        /// <summary>
        /// Load a new profile from the given path
        /// </summary>
        public void LoadProfile(string path)
        {
            using (Stream stream = File.OpenRead(path))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(SerializedColumn[]));
                SerializedColumn[] serializedColumns = (SerializedColumn[])serializer.Deserialize(stream);
                
                LogProfile profile = LogProfile.GetInstance();
                foreach (SerializedColumn serializedColumn in serializedColumns)
                {
                    SsmParameter parameter;
                    Conversion conversion;
                    if (this.database.TryGetParameterById(serializedColumn.ParameterId, out parameter) &&
                        parameter.TryGetConversionByUnits(serializedColumn.ConversionUnits, out conversion))
                    {
                        profile.Add(parameter, conversion);
                    }
                }

                this.SetProfile(profile);
            }
        }

        /// <summary>
        /// For test use only
        /// </summary>
        internal LogEventArgs GetOneRow()
        {
            byte[] rawValues = this.ecu.SyncReadMultiple(this.internalProfile.Addresses);
            this.internalProfile.StoreConvertedValues(rawValues);
            return this.internalProfile.LogEventArgs;
        }
                
        /// <summary>
        /// Invoked by the SsmInterface when the ECU identifier has been received
        /// </summary>
        private void GetEcuIdentifierCallback(IAsyncResult asyncResult)
        {
            ConnectAsyncResult internalState = (ConnectAsyncResult) asyncResult.AsyncState;
            try
            {
                string ecuIdentifier = this.ecu.EndGetEcuIdentifier(asyncResult);
                this.database = SsmParameterDatabase.GetInstance(configurationDirectory, ecuIdentifier);
            }
            catch (Exception ex)
            {
                internalState.Exception = ex;
            }
            internalState.Completed();
        }

        /// <summary>
        /// Invoked by the SsmInterface when the read response has been received
        /// </summary>
        private void EndMultipleReadCallback(IAsyncResult asyncResult)
        {
            byte[] rawValues;
            try
            {
                rawValues = this.ecu.EndMultipleRead(asyncResult);
                InternalLogProfile oldProfile = (InternalLogProfile)asyncResult.AsyncState;
                oldProfile.StoreConvertedValues(rawValues);
                if (this.LogEntry != null)
                {
                    this.LogEntry(this, oldProfile.LogEventArgs);
                }

                if (this.isLogging)
                {
                    InternalLogProfile newProfile = this.internalProfile;
                    if (newProfile != oldProfile)
                    {
                        if (this.LogStop != null)
                        {
                            this.LogStop(this, oldProfile.LogEventArgs);
                        }

                        if (this.LogStart != null)
                        {
                            this.LogStart(this, newProfile.LogEventArgs);
                        }
                    }

                    this.ecu.BeginMultipleRead(newProfile.Addresses, EndMultipleReadCallback, newProfile);
                }
                else
                {
                    if (this.LogStop != null)
                    {
                        this.LogStop(this, new EventArgs());
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
                LogErrorEventArgs args = new LogErrorEventArgs(ex);
                if (this.LogError != null)
                {
                    this.LogError(this, args);
                }

                if (args.ShouldContinue)
                {
                    if (this.isLogging)
                    {
                        this.ecu.BeginMultipleRead(this.internalProfile.Addresses, EndMultipleReadCallback, null);
                    }
                }
                else
                {
                    this.isLogging = false;
                    if (this.LogStop != null)
                    {
                        this.LogStop(this, new EventArgs());
                    }
                }
            }
        }
    }
}
