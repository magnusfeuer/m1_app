///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// Lumberjack.cs
// Core application logic for Win32 and WinCE versions of the SSM logger
///////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.IO.Ports;
using System.Threading;
using NateW.Ssm.Lumberjack.Properties;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Windows.Forms;

namespace NateW.Ssm.Lumberjack
{
    public delegate void VoidVoid();

    public enum LogMode
    {
        None,
        DisplayOnly,
        Constant,
        Defogger,
        OpenLoop,
        ClosedLoop,
        SpaceBar,
    }

    public partial class Lumberjack
    {
        public const string MockEcuPortName = "Mock ECU";
        private IUserInterface ui;
        private SerialPort port;
        private Stream ecuStream;
        private SsmLogger logger;
        private DateTime logStartTime = DateTime.Now;
        private bool currentProfileIsChanged;
        private LogFilter logFilter;
        private bool restartLogging;
        private LogMode logMode = LogMode.DisplayOnly;
        private LogMode startMode = LogMode.None;
        private string startProfile;
        private string startPort;
        private bool ignoreProfileSettingsChangeNotifications;

        public Settings Settings
        {
            get
            {
                return Settings.Default;
            }
        }

        public string EcuIdentifier
        {
            get
            {
                return this.logger.EcuIdentifier;
            }
        }

        public SsmParameterDatabase Database
        {
            get
            {
                return this.logger.Database;
            }
        }

        public DateTime LogStartTime
        {
            get
            {
                return this.logStartTime;
            }
        }

        internal bool CurrentProfileIsChanged
        {
            get
            {
                return this.currentProfileIsChanged;
            }
        }

        public LogMode StartMode
        {
            set
            {
                this.StartMode = value;
            }
        }

        public string StartProfile
        {
            set
            {
                this.startProfile = value;
            }
        }

        public string StartPort
        {
            set
            {
                this.startPort = value;
            }
        }

        public LogMode LogMode
        {
            set
            {
                this.logMode = value;
            }
        }

        public Lumberjack(IUserInterface ui)
        {
            this.ui = ui;
            this.Settings.Reload();
        }

        public void Load()
        {
            this.logFilter = LogFilter.GetInstance(
                this.CreateLogWriter,
                this.ShouldLog);

            this.PopulateLogFolderPath();
            this.PopulateProfileList();
            this.PopulateSerialPortList();

            if (this.startPort != null)
            {
                this.Settings.DefaultPort = this.startPort;
                this.startPort = null;
            }

            if (this.startProfile != null)
            {
                this.Settings.LastProfilePath = this.startProfile;
                this.startProfile = null;
            }

            this.ui.SelectProfile(this.Settings.LastProfilePath);
            this.ui.SelectSerialPort(this.Settings.DefaultPort);

            this.SetTitle();
        }

        public void Closing(ref bool cancel)
        {
            if (this.currentProfileIsChanged)
            {
                if (!PromptToSaveChangedProfile())
                {
                    cancel = true;
                }
            }
        }

        public void Closed()
        {
            this.SaveProfileList();
            this.logger.StopLogging();
        }

        public void ChangeSerialPort()
        {            
            this.ReopenEcuInterface();
        }

        public void Reconnect()
        {
            this.ReopenEcuInterface();
        }

        public void RestartLogging()
        {
            this.restartLogging = true;
            this.logger.StopLogging();
        }

        public void ProfileNew()
        {
            LogProfile empty = LogProfile.GetInstance();
            logger.SetProfile(empty);

            this.Settings.LastProfilePath = null;

            this.ShowNewProfileSettings();
            this.ui.SelectProfile(null);
            this.ui.SaveButtonEnabled = false;
            this.currentProfileIsChanged = false;
            this.SetTitle();
        }

        public void ProfileOpen()
        {
            if (!this.CheckForChanges())
            {
                return;
            }

            string newPath;
            DialogResult result = this.ui.ShowOpenDialog(out newPath);
            if (result == DialogResult.OK && !string.IsNullOrEmpty(newPath))
            {
                this.ui.AddProfile(newPath);
                this.ui.SelectProfile(newPath);
            }
        }

        public void ProfileSave()
        {
            if (string.IsNullOrEmpty(this.Settings.LastProfilePath))
            {
                this.ProfileSaveAs();
                return;
            }

            this.logger.SaveProfile(this.Settings.LastProfilePath);
            this.currentProfileIsChanged = false;
            this.SetTitle();
        }

        public void ProfileSaveAs()
        {
            string newPath;
            DialogResult result = this.ui.ShowSaveAsDialog(out newPath);

            if (result == DialogResult.OK && !string.IsNullOrEmpty(newPath))
            {
                this.logger.SaveProfile(newPath);
                this.currentProfileIsChanged = false;

                this.ui.AddProfile(newPath);
                this.ui.SelectProfile(newPath);
                this.ui.SaveButtonEnabled = true;
                this.SetTitle();
            }
        }

        public void SelectedProfileChanged()
        {
            if (!this.CheckForChanges())
            {
                return;
            }

            string profilePath = this.ui.GetSelectedProfile();
            if (profilePath == null)
            {
                this.ui.SaveButtonEnabled = false;
            }

            this.ChangeProfile(profilePath);
        }

        public void SelectedProfileSettingsChanged()
        {
            if (this.logger == null)
            {
                return;
            }

            if (this.ignoreProfileSettingsChangeNotifications)
            {
                return;
            }

            bool startLogging = this.logger.IsLogging;

            LogProfile profile = LogProfile.GetInstance();
            this.ui.GetNewProfileSettings(profile);
            this.ui.SaveButtonEnabled = true;
            this.logger.SetProfile(profile);

            this.currentProfileIsChanged = true;
            this.SetTitle();
        }
        
        public void SetLoggingFolder()
        {
            string path;
            DialogResult result = this.ui.PromptForLoggingFolder(out path);
            this.Settings.LogFolderPath = path;
        }

        public void SetLogMode(LogMode mode)
        {
            this.logMode = mode;
        }

        /// <summary>
        /// Directory with canned profiles & SSM database
        /// </summary>
        /// <remarks>For test use only</remarks>
        /// <returns>Directory with canned profiles & SSM database</returns>
        internal string GetConfigurationDirectory()
        {
            string assemblyPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            if (assemblyPath.Contains("TestResults"))
            {
                string[] parts = assemblyPath.Split(Path.DirectorySeparatorChar);
                assemblyPath = string.Join(Path.DirectorySeparatorChar.ToString(), parts, 0, parts.Length - 3);
            }
            assemblyPath = Path.GetDirectoryName(assemblyPath);
            string result = Path.Combine(assemblyPath, "Configuration");
            return result;
        }
    }
}
