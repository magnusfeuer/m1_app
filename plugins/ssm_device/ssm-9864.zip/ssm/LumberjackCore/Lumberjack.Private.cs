///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// Lumberjack.Private.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.IO.Ports;
using System.Threading;
using NateW.Ssm.Lumberjack.Properties;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Windows.Forms;

namespace NateW.Ssm.Lumberjack
{
    public partial class Lumberjack
    {
        private bool CheckForChanges()
        {
            if (this.currentProfileIsChanged)
            {
                if (!PromptToSaveChangedProfile())
                {
                    return false;
                }
            }
            return true;
        }

        private void ChangeProfile(string newProfilePath)
        {
            if (string.IsNullOrEmpty(newProfilePath))
            {
                return;
            }

            this.logger.LoadProfile(newProfilePath);
            this.Settings.LastProfilePath = newProfilePath;
            this.ignoreProfileSettingsChangeNotifications = true;
            this.ShowNewProfileSettings();
            this.ignoreProfileSettingsChangeNotifications = false;
            this.ui.SaveButtonEnabled = true;
            this.ui.SetLogMode(LogMode.DisplayOnly);
            this.currentProfileIsChanged = false;
            this.SetTitle();
            this.logger.StartLogging();
        }

        private void SaveProfileList()
        {
            StringCollection paths = this.Settings.RecentProfiles;
            if (paths == null)
            {
                paths = new StringCollection();
            }
            paths.Clear();

            foreach (PathDisplayAdaptor adaptor in this.ui.Profiles)
            {
                paths.Add(adaptor.Path);
            }

            this.Settings.RecentProfiles = paths;
            this.Settings.Save();
        }

        private void PopulateSerialPortList()
        {
            this.ui.AddSerialPort(MockEcuPortName);
            foreach (string name in System.IO.Ports.SerialPort.GetPortNames())
            {
                this.ui.AddSerialPort(name);
            }

            string lastPort = this.Settings.DefaultPort;
            if (!this.ui.SerialPortListContains(lastPort))
            {
                lastPort = MockEcuPortName;
            }

            this.ui.SelectSerialPort(lastPort);
        }

        private void PopulateProfileList()
        {
            if (this.Settings.RecentProfiles != null)
            {
                foreach (string path in this.Settings.RecentProfiles)
                {
                    if (File.Exists(path))
                    {
                        this.ui.AddProfile(path);
                    }
                }
            }
        }

        private void PopulateLogFolderPath()
        {
            if (string.IsNullOrEmpty(this.Settings.LogFolderPath))
            {
                this.Settings.LogFolderPath = Environment.GetEnvironmentVariable("HOMEPATH");
            }
            this.ui.ShowLogFolder(this.Settings.LogFolderPath);
        }

        private void ShowNewProfileSettings()
        {
            bool changed = this.currentProfileIsChanged;
            this.ui.ShowNewProfileSettings(this.logger.CurrentProfile);
            this.currentProfileIsChanged = changed;
        }

        private void SetTitle()
        {
            StringBuilder builder = new StringBuilder(100);
            builder.Append("Lumberjack");
            builder.Append(" - ");
            
            string selectedPort = this.ui.GetSelectedSerialPort();
            if (selectedPort != null)
            {
                builder.Append(selectedPort);
                builder.Append(" - ");
            }

            if (!string.IsNullOrEmpty(this.Settings.LastProfilePath))
            {
                builder.Append(new PathDisplayAdaptor(this.Settings.LastProfilePath).ToString());
            }
            else
            {
                builder.Append("new profile");
            }

            if (this.currentProfileIsChanged)
            {
                builder.Append('*');
            }
            string title = builder.ToString();
            this.ui.SetTitle(title);
        }

        private void ReopenEcuInterface()
        {
            this.CloseEcuInterface();

            string portName = this.ui.GetSelectedSerialPort();
            if (!string.IsNullOrEmpty(portName))
            {
                this.OpenEcuInterface(portName);
            }
        }

        private void CloseEcuInterface()
        {
            Trace("CloseEcuInterface");

            if (this.logger != null)
            {
                this.logger.StopLogging();
                this.logger = null;
            }

            if (this.ecuStream != null)
            {
                this.ecuStream.Dispose();
                this.ecuStream = null;
            }

            if (this.port != null)
            {
                this.port.Dispose();
                this.port = null;
            }

            this.ui.ConnectionStateChanged(false);
        }

        private void OpenEcuInterface(string name)
        {
            Trace("OpenEcuInterface");

            if (name == MockEcuPortName)
            {
                this.ecuStream = MockEcuStream.GetInstance();
            }
            else
            {
                this.port = new SerialPort(name, 4800, Parity.None, 8, StopBits.One);
                this.port.Open();
                this.port.ReadTimeout = 2000;
                this.ecuStream = this.port.BaseStream;
            }

            string configurationDirectory = this.GetConfigurationDirectory();
            this.logger = SsmLogger.GetInstance(configurationDirectory, this.ecuStream);
            this.logger.LogStart += this.LogStart;
            this.logger.LogEntry += this.LogEntry;
            this.logger.LogStop += this.LogStop;
            this.logger.LogError += this.LogError;

            this.logger.BeginConnect(ConnectCallback, name);
        }

        private void ConnectCallback(IAsyncResult asyncResult)
        {
            Trace("ConnectCallback");

            if (this.logger == null)
            {
                return;
            }

            try
            {
                this.logger.EndConnect(asyncResult);
            }
            catch (BadPacketException ex)
            {
                this.ui.Invoke(new ThreadStart(
                    delegate
                    {
                        this.ui.RenderError(ex);
                        this.ui.ConnectionStateChanged(false);
                    }));
                return;
            }

            try
            {
                this.ui.Invoke(new ThreadStart(
                delegate
                {
                    this.ui.PopulateParameterList(this.logger.Database);
                    this.ui.ConnectionStateChanged(true);

                    this.LoadProfile();

                    this.Settings.DefaultPort = (string)asyncResult.AsyncState;
                    this.currentProfileIsChanged = false;

                    if (this.startMode != LogMode.None)
                    {
                        this.ui.SetLogMode(this.startMode);
                        this.startMode = LogMode.None;
                    }
                }));
            }
            catch (Exception ex)
            {
                this.ui.Invoke(new ThreadStart(
                    delegate
                    {
                        this.ui.RenderError(ex);
                    }));
            }
        }

        private void LoadProfile()
        {
            if (this.currentProfileIsChanged)
            {
                string oldPath = new PathDisplayAdaptor(this.Settings.LastProfilePath).ToString();
                DialogResult dialogResult = this.ui.PromptToSaveProfileBeforeChanging(oldPath);

                if (dialogResult == DialogResult.Cancel)
                {
                    this.ui.SelectProfile(this.Settings.LastProfilePath);
                    return;
                }
                else if (dialogResult == DialogResult.Yes)
                {
                    this.logger.SaveProfile(this.Settings.LastProfilePath);
                }
            }

            string profilePath = this.ui.GetSelectedProfile();
            if (profilePath == null)
            {
                this.ui.SaveButtonEnabled = false;
                return;
            }

            this.logger.LoadProfile(profilePath);
            this.logger.StartLogging();
            this.Settings.LastProfilePath = profilePath;
            this.ui.ShowNewProfileSettings(this.logger.CurrentProfile);
            this.ui.SelectProfile(this.Settings.LastProfilePath);
            this.currentProfileIsChanged = false;
            this.ui.SaveButtonEnabled = true;
            this.SetTitle();
        }

        private bool PromptToSaveChangedProfile()
        {
            string oldPath = this.Settings.LastProfilePath.ToString();
            DialogResult saveResult = this.ui.PromptToSaveProfileBeforeChanging(oldPath);

            if (saveResult == DialogResult.Cancel)
            {
                return false;
            }
            else if (saveResult == DialogResult.Yes)
            {
                this.logger.SaveProfile(this.Settings.LastProfilePath);
            }

            return true;
        }

        private void Trace(string s)
        {
            Debug.WriteLine(s);
        }
    }
}
