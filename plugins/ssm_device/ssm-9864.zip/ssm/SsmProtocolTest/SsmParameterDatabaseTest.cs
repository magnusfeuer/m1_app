///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// SsmParameterDatabaseTest.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NateW.Ssm;

namespace SsmDisplayTest
{
    /// <summary>
    /// Summary description for LogProfileDatabaseTests
    /// </summary>
    [TestClass]
    public class SsmParameterDatabaseTest
    {
        //private const string ecuIdentifier = "1B04400405";
        private const string ecuIdentifier = "29044A4105";
        
        public SsmParameterDatabaseTest()
        {
            Utility.CopyConfigurationFiles();
        }

        [TestMethod]
        public void DatabaseGetStandardParameters_XPath()
        {
            DatabaseGetStandardParameters(false);
        }

        [TestMethod]
        public void DatabaseGetStandardParameters_XmlReader()
        {
            DatabaseGetStandardParameters(true);
        }

        [TestMethod]
        public void DatabaseGetExtendedParameters_XPath()
        {
            DatabaseGetExtendedParameters(false);
        }

        [TestMethod]
        public void DatabaseGetExtendedParameters_XmlReader()
        {
            DatabaseGetExtendedParameters(true);
        }

        [TestMethod]
        public void DatabaseGetSwitches_XPath()
        {
            DatabaseGetSwitches(false);
        }

        [TestMethod]
        public void DatabaseGetSwitches_XmlReader()
        {
            DatabaseGetSwitches(true);
        }

        private void DatabaseGetStandardParameters(bool useXmlReader)
        {
            ReadOnlyCollection<SsmParameter> noDependencies = null;
            List<SsmParameter> expectedList = new List<SsmParameter>();
            expectedList.Add(new SsmParameter(
                "P1",
                "Engine Load",
                0x000007,
                1,
                new Conversion[] { Conversion.GetInstance("%", "x*100/255", "0.00") },
                8,
                7,
                noDependencies));
            expectedList.Add(new SsmParameter(
                "P2",
                "Coolant Temperature",
                0x000008,
                1,
                new Conversion[] { 
                    Conversion.GetInstance("F", "32+9*(x-40)/5", "0"),
                    Conversion.GetInstance("C", "x-40", "0")
                },
                8,
                6,
                noDependencies));
            expectedList.Add(new SsmParameter(
                "P8",
                "Engine Speed",
                0x00000E,
                2,
                new Conversion[] { Conversion.GetInstance("rpm", "x/4", "0") },
                8,
                0,
                noDependencies));

            SsmParameterDatabase database = new SsmParameterDatabase(null);
            using (Stream inputStream = File.OpenRead("logger.xml")) 
            {
                if (useXmlReader)
                {
                    XmlReader reader = XmlReader.Create(inputStream);
                    database.LoadStandardParameters(reader);
                }
                else
                {
                    XPathDocument document = SsmParameterDatabase.CreateDocument(inputStream);
                    database.LoadStandardParameters(document);
                }
            }

            Assert.AreEqual(92, database.Parameters.Count, "Parameters.Count");
            SsmParameterDatabaseTest.CompareLists(expectedList, database.Parameters);
        }

        private void DatabaseGetExtendedParameters(bool useXmlReader)
        {
            List<SsmParameter> expectedList = new List<SsmParameter>();
            expectedList.Add(new SsmParameter(
                "E1",
                "IAM*",
                0x20124, //0x20118,
                4,
                new Conversion[] { 
                    Conversion.GetInstance("raw ecu value", "x", "0"),
                    Conversion.GetInstance("multiplier", "x/16", "0.000")
                }));

            expectedList.Add(new SsmParameter(
                "E2",
                "Engine Load*",
                0x2009A, //0x21847,
                4,
                new Conversion[] { 
                    Conversion.GetInstance("g/rev", "x*.00006103515625", "0.00"),
                }));

            SsmParameterDatabase database = new SsmParameterDatabase(ecuIdentifier);
            using (Stream inputStream = File.OpenRead("logger.xml"))
            {
                if (useXmlReader)
                {
                    XmlReader reader = XmlReader.Create(inputStream);
                    database.LoadExtendedParameters(reader);
                }
                else
                {
                    XPathDocument document = SsmParameterDatabase.CreateDocument(inputStream);
                    database.LoadExtendedParameters(document);
                }
            }

            Assert.AreEqual(22, database.Parameters.Count, "Parameters.Count");
            Console.WriteLine("Count: " + database.Parameters.Count);

            foreach (SsmParameter parameter in database.Parameters)
            {
                Console.WriteLine(
                    string.Format(
                        "Parameter: {0,50} ID {1,5} Address {2,10}",
                            parameter.Name,
                            parameter.Id,
                            parameter.Address));
            }

            SsmParameterDatabaseTest.CompareLists(expectedList, database.Parameters);
        }

        private void DatabaseGetSwitches(bool useXmlReader)
        {
            List<SsmParameter> expectedList = new List<SsmParameter>();
            expectedList.Add(new SsmParameter("S20", "Defogger Switch", 0x64, 1, new Conversion[] { Conversion.GetInstance(Conversion.Boolean, "x&(2^5)", "") }));
            expectedList.Add(new SsmParameter("S65", "Set/Coast Switch", 0x121, 1, new Conversion[] { Conversion.GetInstance(Conversion.Boolean, "x&(2^5)", "") }));
            expectedList.Add(new SsmParameter("S66", "Resume/Accelerate Switch", 0x121, 1, new Conversion[] { Conversion.GetInstance(Conversion.Boolean, "x&(2^4)", "") }));
            SsmParameterDatabase database = new SsmParameterDatabase(ecuIdentifier);

            using (Stream inputStream = File.OpenRead("logger.xml"))
            {
                if (useXmlReader)
                {
                    XmlReader reader = XmlReader.Create(inputStream);
                    database.LoadSwitches(reader);
                }
                else
                {
                    XPathDocument document = SsmParameterDatabase.CreateDocument(inputStream);
                    database.LoadSwitches(document);
                }
            }

            Assert.AreEqual(68, database.Parameters.Count, "Switches.Count");
            Console.WriteLine("Count: " + database.Parameters.Count);

            foreach (SsmParameter parameter in database.Parameters)
            {
                Console.WriteLine(
                    string.Format(
                        "Parameter: {0,50} ID {1,5} Address {2,10} Conversion {3,10}",
                            parameter.Name,
                            parameter.Id,
                            parameter.Address,
                            parameter.Conversions[0]));
            }

            SsmParameterDatabaseTest.CompareLists(expectedList, database.Parameters);
        }
        
        [TestMethod]
        public void DatabaseGetCalculatedParameters()
        {
            SsmParameterDatabase database = SsmParameterDatabase.GetInstance(Environment.CurrentDirectory, ecuIdentifier);
            using (Stream inputStream = File.OpenRead("logger.xml"))
            {
#if XPath
               PathDocument document = SsmParameterDatabase.CreateDocument(inputStream);
                database.LoadExtendedParameters(document);
#else
                XmlReader reader = XmlReader.Create(inputStream);
                database.LoadExtendedParameters(reader);
#endif
            }

            SsmParameter engineSpeed = null;
            SsmParameter maf = null;
            SsmParameter load = null;
            foreach (SsmParameter parameter in database.Parameters)
            {
                if (parameter.Id == "P8")
                {
                    engineSpeed = parameter;
                }

                if (parameter.Id == "P12")
                {
                    maf = parameter;
                }

                if (parameter.Id == "P200")
                {
                    load = parameter;
                }
            }

            Assert.AreSame(engineSpeed, load.Dependencies[0], "First dependency");
            Assert.AreSame(maf, load.Dependencies[1], "Second dependency");
        }

        [TestMethod]
        public void DatabaseCompareMethods()
        {
            // XPath method
            SsmParameterDatabase xpathDatabase = new SsmParameterDatabase(ecuIdentifier);
            using (Stream stream = File.OpenRead("logger.xml"))
            {
                XPathDocument document = SsmParameterDatabase.CreateDocument(stream);
                xpathDatabase.LoadExtendedParameters(document);
                xpathDatabase.LoadStandardParameters(document);
            }

            // XmlReader method
            SsmParameterDatabase xmlReaderDatabase = new SsmParameterDatabase(ecuIdentifier);
            using (Stream stream = File.OpenRead("logger.xml"))
            {
                XmlReader reader = XmlReader.Create(stream);
                xmlReaderDatabase.LoadStandardParameters(reader);

                stream.Position = 0;
                reader = XmlReader.Create(stream);
                xmlReaderDatabase.LoadExtendedParameters(reader);
            }

            Assert.AreEqual(xpathDatabase.Parameters.Count, xmlReaderDatabase.Parameters.Count, "Counts");
            CompareLists(xpathDatabase.Parameters, xmlReaderDatabase.Parameters);
        }

        private static void CompareLists(IList<SsmParameter> expectedList, IList<SsmParameter> actualList)
        {
            foreach (SsmParameter expected in expectedList)
            {
                SsmParameter actual = null;
                if (!SsmParameterDatabaseTest.TryGetParameter(actualList, expected.Id, out actual))
                {
                    throw new Exception("Actual list does not contain " + expected.Name + " (" + expected.Id + ")");
                }
                                
                Assert.AreEqual(expected.Conversions.Count, actual.Conversions.Count, "Conversions.Count");
                for (int i = 0; i < actual.Conversions.Count; i++)
                {
                    Assert.AreEqual(
                        expected.Conversions[i].Units, 
                        actual.Conversions[i].Units, 
                        "Conversions[i].Units");

                    Assert.AreEqual(
                        expected.Conversions[i].Expression, 
                        actual.Conversions[i].Expression, 
                        "Conversions[i].Expression");

                    Assert.AreEqual(
                        expected.Conversions[i].Format, 
                        actual.Conversions[i].Format, 
                        "Conversions[i].Format");
                }

                Assert.AreEqual(expected.Id, actual.Id, actual.Name + " Id");

                if (expected.IsCalculated)
                {
                    Assert.IsTrue(actual.IsCalculated, "IsCalculated");
                    Assert.IsTrue(actual.Dependencies != null, "Dependencies != null");
                    Assert.IsTrue(actual.Dependencies.Count > 0, "Dependencies.Count > 0");
                }
                else
                {
                    Assert.AreEqual(expected.Address, actual.Address, actual.Name + " Address");
                    Assert.IsTrue(actual.Dependencies == null, "Dependencies == null");
                }

                Assert.AreEqual(expected.EcuCapabilityByteIndex, actual.EcuCapabilityByteIndex, actual.Name + " EcuCapabilityByteIndex");
                Assert.AreEqual(expected.EcuCapabilityBitIndex, actual.EcuCapabilityBitIndex, actual.Name + " EcuCapabilityBitIndex");
            }

            // TODO: ensure no extra parameters
        }

        private static bool TryGetParameter(IList<SsmParameter> actualList, string id, out SsmParameter actual)
        {
            foreach (SsmParameter candidate in actualList)
            {
                if (candidate.Id == id)
                {
                    actual = candidate;
                    return true;
                }
            }
            actual = null;
            return false;
        }
    }
}