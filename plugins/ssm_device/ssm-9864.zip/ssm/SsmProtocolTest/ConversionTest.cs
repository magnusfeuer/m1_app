﻿///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// ConversionTest.cs
///////////////////////////////////////////////////////////////////////////////
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Text;
using System.Collections.Generic;
using NateW.Ssm;

namespace SsmLoggerTest
{
    [TestClass()]
    public class ConversionTest
    {
        private TestContext testContextInstance;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        [TestMethod()]
        public void ConvertX()
        {
            Conversion conversion = Conversion.GetInstance("units", "x", "0.00");
            string actual = conversion.Convert(1.23);
            Assert.AreEqual("1.23", actual);

            conversion = Conversion.GetInstance("units", "x", "0");
            actual = conversion.Convert(1);
            Assert.AreEqual("1", actual);
        }

        [TestMethod()]
        public void ConvertXOver4()
        {
            Conversion conversion = Conversion.GetInstance("units", "x/4", "0.00");
            string actual = conversion.Convert(17);
            Assert.AreEqual("4.25", actual);
        }

        [TestMethod()]
        public void ConvertBoolean()
        {
            Conversion conversion = Conversion.GetInstance(Conversion.Boolean, "x&4", "");
            string actual = conversion.Convert(0);
            Assert.AreEqual(false.ToString(), actual);

            conversion = Conversion.GetInstance(Conversion.Boolean, "x&4", "");
            actual = conversion.Convert(4);
            Assert.AreEqual(true.ToString(), actual);

            conversion = Conversion.GetInstance(Conversion.Boolean, "x&4", "");
            actual = conversion.Convert(5);
            Assert.AreEqual(true.ToString(), actual);

            conversion = Conversion.GetInstance(Conversion.Boolean, "x&4", "");
            actual = conversion.Convert(1);
            Assert.AreEqual(false.ToString(), actual);
        }        
    }
}
