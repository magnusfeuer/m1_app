﻿///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// SsmInterfaceTest.cs
///////////////////////////////////////////////////////////////////////////////
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Threading;
using NateW.Ssm;

namespace SsmDisplayTest
{
    /// <summary>
    ///This is a test class for NateW.Ssm.SsmPacket and is intended
    ///to contain all NateW.Ssm.SsmPacket Unit Tests
    ///</summary>
    [TestClass()]
    public class SsmInterfaceTest
    {
        private TestContext testContextInstance;
        private string ecuIdentifier;
        private byte[] values;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        /// <summary>
        ///A test for CreateEcuInitRequest ()
        ///</summary>
        [TestMethod()]
        public void SsmInterfaceGetEcuIdentifier()
        {
            MockEcuStream stream = MockEcuStream.GetInstance();
            SsmInterface ssm = SsmInterface.GetInstance(stream);
            this.ecuIdentifier = null;
            IAsyncResult asyncResult = ssm.BeginGetEcuIdentifier(GetEcuIdentifierCallack, ssm);
            asyncResult.AsyncWaitHandle.WaitOne();
            Assert.AreEqual("2F12785206", this.ecuIdentifier, "EcuIdentifier");
        }

        private void GetEcuIdentifierCallack(IAsyncResult asyncResult)
        {
            SsmInterface ssm = (SsmInterface) asyncResult.AsyncState;
            this.ecuIdentifier = ssm.EndGetEcuIdentifier(asyncResult);
        }

        [TestMethod()]
        public void SsmInterfaceMultipleRead()
        {
            MockEcuStream stream = MockEcuStream.GetInstance();
            SsmInterface ssm = SsmInterface.GetInstance(stream);
            IList<UInt32> addresses = new List<UInt32>();
            addresses.Add(0x29);
            addresses.Add(0x20);
            this.values = null;
            IAsyncResult asyncResult = ssm.BeginMultipleRead(addresses, MultipleReadCallack, ssm);
            asyncResult.AsyncWaitHandle.WaitOne();
            Assert.AreEqual(2, this.values.Length, "Values.Count");
        }

        private void MultipleReadCallack(IAsyncResult asyncResult)
        {
            SsmInterface ssm = (SsmInterface)asyncResult.AsyncState;
            this.values = ssm.EndMultipleRead(asyncResult);
        }

        [TestMethod]
        public void SsmInterfaceSyncReadMultiple()
        {
            MockEcuStream stream = MockEcuStream.GetInstance();
            SsmInterface ssm = SsmInterface.GetInstance(stream);
            List<UInt32> addresses = new List<UInt32>();
            addresses.Add(0x000029);
            addresses.Add(0x000020);
            byte[] values = ssm.SyncReadMultiple(addresses);
            Assert.AreEqual(values.Length, addresses.Count, "Values.Count");
        }
    }
}
