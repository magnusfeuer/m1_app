﻿///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// LogProfileTest.cs
///////////////////////////////////////////////////////////////////////////////
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Text;
using System.Collections.Generic;
using NateW.Ssm;

namespace SsmDisplayTest
{
    [TestClass()]
    public class LogProfileTest
    {
        private SsmLogger logger;
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        public LogProfileTest()
        {
            Utility.CopyConfigurationFiles();
        }

        [TestMethod()]
        public void LogProfileSaveAndReload()
        {
            this.InitializeLogger();

            LogProfile expectedProfile = LogProfile.GetInstance();
            foreach (SsmParameter parameter in this.logger.Database.Parameters)
            {
                expectedProfile.Add(parameter, parameter.Conversions[0]);
                if (expectedProfile.Parameters.Count > 3)
                {
                    break;
                }
            }

            this.logger.SetProfile(expectedProfile);
            this.logger.SaveProfile("profile.xml");

            LogProfile emptyProfile = LogProfile.GetInstance();
            this.logger.SetProfile(emptyProfile);

            this.logger.LoadProfile("profile.xml");
            LogProfile actualProfile = this.logger.CurrentProfile;

            foreach (SsmParameter parameter in actualProfile.Parameters)
            {
                Assert.IsTrue(expectedProfile.Contains(parameter));
            }

            foreach (SsmParameter parameter in expectedProfile.Parameters)
            {
                Assert.IsTrue(actualProfile.Contains(parameter));
            }
        }

        private void ConnectCallback(IAsyncResult asyncResult)
        {
            this.logger.EndConnect(asyncResult);
        }

        private void InitializeLogger()
        {
            MockEcuStream stream = MockEcuStream.GetInstance();
            this.logger = SsmLogger.GetInstance(Environment.CurrentDirectory, stream);
            IAsyncResult result = logger.BeginConnect(ConnectCallback, null);
            result.AsyncWaitHandle.WaitOne();
            logger.EndConnect(result);
            Assert.AreEqual("2F12785206", this.logger.EcuIdentifier, "EcuIdentifier");
            Assert.IsNotNull(this.logger.Database.Parameters);
        }
    }
}
