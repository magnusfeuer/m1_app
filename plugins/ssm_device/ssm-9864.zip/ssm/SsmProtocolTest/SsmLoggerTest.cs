﻿///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// SsmLoggerTest.cs
///////////////////////////////////////////////////////////////////////////////
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Text;
using System.Collections.Generic;
using NateW.Ssm;

namespace SsmDisplayTest
{
    [TestClass()]
    public class SsmLoggerTest
    {
        public delegate void VoidVoid();
        private TestContext testContextInstance;
        private SsmLogger logger;
        private int logStartCalls;
        private int logEntryCalls;
        private int logEntryCallsAfterChange;
        private int logEndCalls;
        private int logErrorCalls;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        public SsmLoggerTest()
        {
            Utility.CopyConfigurationFiles();
        }

        [TestMethod()]
        public void LoggerConnect()
        {
            MockEcuStream mock = MockEcuStream.GetInstance();
            FragmentedStream stream = FragmentedStream.GetInstance(mock);
            this.logger = SsmLogger.GetInstance(Environment.CurrentDirectory, stream);
            IAsyncResult result = logger.BeginConnect(ConnectCallback, null);
            result.AsyncWaitHandle.WaitOne();
            Assert.AreEqual("2F12785206", this.logger.EcuIdentifier, "EcuIdentifier");
            Assert.IsNotNull(this.logger.Database.Parameters);
        }

        private void ConnectCallback(IAsyncResult asyncResult)
        {
            this.logger.EndConnect(asyncResult);
        }

        [TestMethod()]
        public void LoggerManualLogging()
        {
            ManualLoggingTest(delegate { });

            Console.WriteLine("LogEntry calls: " + this.logEntryCalls);
            Assert.AreEqual(1, this.logStartCalls, "LogStart calls");
            Assert.IsTrue(this.logEntryCalls > 1, "LogEntry calls > 1");
            Assert.AreEqual(1, this.logEndCalls, "LogEnd calls");
            Assert.AreEqual(0, this.logErrorCalls, "LogError calls");
        }

        [TestMethod()]
        public void LoggerManualLoggingChangeProfile()
        {
            ManualLoggingTest(delegate
            {
                System.Threading.Thread.Sleep(TimeSpan.FromSeconds(0.1));
                int entriesBefore = this.logEntryCalls;

                LogProfile newProfile = LogProfile.GetInstance();
                foreach (SsmParameter parameter in logger.Database.Parameters)
                {
                    switch (parameter.Name)
                    {
                        case "Injector Duty Cycle":
                        case "Manifold Rel. Pressure (Corrected)":
                            newProfile.Add(parameter, parameter.Conversions[0]);
                            break;
                    }
                }

                this.logger.SetProfile(newProfile);
                System.Threading.Thread.Sleep(TimeSpan.FromSeconds(0.5));
                int entriesAfter = this.logEntryCalls;
                this.logEntryCallsAfterChange = entriesAfter - entriesBefore;
            });

            Console.WriteLine("LogEntry calls: " + this.logEntryCalls);
            Assert.AreEqual(2, this.logStartCalls, "LogStart calls");
            Assert.IsTrue(this.logEntryCalls > 1, "LogEntry calls > 1");
            Assert.IsTrue(this.logEntryCallsAfterChange > 3, "LogEntry calls after change");
            Assert.AreEqual(2, this.logEndCalls, "LogEnd calls");
            Assert.AreEqual(0, this.logErrorCalls, "LogError calls");
        }

        public void ManualLoggingTest(VoidVoid callback)
        {
            MockEcuStream stream = MockEcuStream.GetInstance();
            FragmentedStream fragStream = FragmentedStream.GetInstance(stream);
            this.logger = SsmLogger.GetInstance(Environment.CurrentDirectory, fragStream);
            IAsyncResult result = logger.BeginConnect(ConnectCallback, null);
            result.AsyncWaitHandle.WaitOne();

            LogProfile Profile = LogProfile.GetInstance();
            foreach (SsmParameter parameter in logger.Database.Parameters)
            {
                Profile.Add(parameter, parameter.Conversions[0]);
                if (Profile.Parameters.Count > 3)
                {
                    break;
                }
            }

            this.logStartCalls = 0;
            this.logEntryCalls = 0;
            this.logEndCalls = 0;
            this.logErrorCalls = 0;

            this.logger.SetProfile(Profile);
            this.logger.LogStart += this.LogStart;
            this.logger.LogEntry += this.LogEntry;
            this.logger.LogStop += this.LogStop;
            this.logger.LogError += this.LogError;

            this.logger.StartLogging();
            System.Threading.Thread.Sleep(TimeSpan.FromSeconds(0.25));
            callback();
            this.logger.StopLogging();
            System.Threading.Thread.Sleep(TimeSpan.FromSeconds(0.1));
        }

        private void LogStart(object sender, LogEventArgs args)
        {
            this.logStartCalls++;
        }

        private void LogEntry(object sender, LogEventArgs args)
        {
            this.logEntryCalls++;
        }

        private void LogStop(object sender, EventArgs args)
        {
            this.logEndCalls++;
        }

        private void LogError(object sender, LogErrorEventArgs args)
        {
            Console.WriteLine(args.Exception.ToString());
            this.logErrorCalls++;
        }

        [TestMethod()]
        public void LoggerProfile()
        {
            MockEcuStream stream = MockEcuStream.GetInstance();
            this.logger = SsmLogger.GetInstance(Environment.CurrentDirectory, stream);
            IAsyncResult result = logger.BeginConnect(ConnectCallback, null);
            result.AsyncWaitHandle.WaitOne();

            LogProfile expectedProfile = LogProfile.GetInstance();
            foreach (SsmParameter parameter in logger.Database.Parameters)
            {
                expectedProfile.Add(parameter, parameter.Conversions[0]);
                if (expectedProfile.Parameters.Count > 3)
                {
                    break;
                }
            }
            logger.SetProfile(expectedProfile);
            LogProfile actualProfile = logger.CurrentProfile;

            Assert.AreEqual(expectedProfile.Parameters.Count, actualProfile.Parameters.Count, "Actual count and expected count");
            foreach (SsmParameter expectedParameter in expectedProfile.Parameters)
            {
                Assert.IsTrue(actualProfile.Contains(expectedParameter), "Actual expected parameter set is missing something");
            }
            foreach (SsmParameter actualParameter in actualProfile.Parameters)
            {
                Assert.IsTrue(expectedProfile.Contains(actualParameter), "Actual expected parameter set contains something extra");
            }
        }

        [TestMethod()]
        public void LoggerAddresses()
        {
            MockEcuStream stream = MockEcuStream.GetInstance();
            SsmLogger logger = SsmLogger.GetInstance(Environment.CurrentDirectory, stream);
            logger.BeginConnect(null, null).AsyncWaitHandle.WaitOne();
            LogProfile profile = LogProfile.GetInstance();            
            foreach (SsmParameter parameter in logger.Database.Parameters)
            {
                profile.Add(parameter, parameter.Conversions[0]);
                if (profile.Parameters.Count == 8)
                {
                    break;
                }
            }
            logger.SetProfile(profile);
            IList<UInt32> actual = logger.Addresses;
            IList<UInt32> expected = new UInt32[]
            {
                7, 8, 9, 0xA, 0xB, 0xC, 0xD, 0xE, 0xF
            };

            Assert.AreEqual(expected.Count, actual.Count, "Addresses.Length");
            for (int i = 0; i < expected.Count; i++)
            {
                Assert.AreEqual(expected[i], actual[i], "Addresses[" + i + "]");
            }
        }

        [TestMethod()]
        public void LoggerAddressesDuplicates()
        {
            MockEcuStream stream = MockEcuStream.GetInstance();
            this.logger = SsmLogger.GetInstance(Environment.CurrentDirectory, stream);
            IAsyncResult result = logger.BeginConnect(ConnectCallback, null);
            result.AsyncWaitHandle.WaitOne();
            LogProfile profile = LogProfile.GetInstance();
            SsmParameter parameter;            

            logger.Database.TryGetParameterById("P8", out parameter);
            profile.Add(parameter, parameter.Conversions[0]);
            logger.Database.TryGetParameterById("P201", out parameter);
            profile.Add(parameter, parameter.Conversions[0]);
            logger.Database.TryGetParameterById("P202", out parameter);
            profile.Add(parameter, parameter.Conversions[0]);
            logger.Database.TryGetParameterById("P7", out parameter);
            profile.Add(parameter, parameter.Conversions[0]);

            this.logger.SetProfile(profile);

            List<UInt32> addresses = this.logger.Addresses;
            Assert.AreEqual(5, addresses.Count);
            UInt32[] expected = new UInt32[] { 14, 15, 32, 13, 35 };
            Utility.CompareArrays(expected, addresses.ToArray());
        }

        [TestMethod()]
        public void LoggerDependencyConversions()
        {
            MockEcuStream stream = MockEcuStream.GetInstance();
            this.logger = SsmLogger.GetInstance(Environment.CurrentDirectory, stream);
            IAsyncResult result = logger.BeginConnect(ConnectCallback, null);
            result.AsyncWaitHandle.WaitOne();

            LogProfile baseParameters = LogProfile.GetInstance();
            foreach (SsmParameter parameter in logger.Database.Parameters)
            {
                if (parameter.Id == "P201")
                {
                    baseParameters.Add(parameter, parameter.Conversions[0]);
                }

                if (parameter.Id == "P202")
                {
                    baseParameters.Add(parameter, parameter.Conversions[0]);
                    break;
                }
            }

            this.logger.SetProfile(baseParameters);

            LogEventArgs args = this.logger.GetOneRow();

            AssertColumnParameterId(args, 0, "P8");
            AssertColumnParameterId(args, 1, "P21");
            AssertColumnParameterId(args, 2, "P201");
            AssertColumnParameterId(args, 3, "P7");
            AssertColumnParameterId(args, 4, "P24");
            AssertColumnParameterId(args, 5, "P202");

            Assert.AreEqual(6, args.Row.Columns.Count);

            List<UInt32> addresses = this.logger.Addresses;
            Assert.AreEqual(5, addresses.Count);
            UInt32[] expected = new UInt32[] { 14, 15, 32, 13, 35 };
            Utility.CompareArrays(expected, addresses.ToArray());

            // Values from observation...  
            Assert.AreEqual("2.08", args.Row.Columns[2].Value);
            Assert.AreEqual("1.02", args.Row.Columns[5].Value);
        }

        private static void AssertColumnParameterId(LogEventArgs args, int column, string expected)
        {
            string actual = args.Row.Columns[column].Parameter.Id;
            Assert.AreEqual(expected, actual, 
                string.Format(
                    "Column {0} parameter ID", column));
        }

        private static void AssertContains(LogProfile profile, string parameterId, string conversionUnits)
        {
            foreach (SsmParameter parameter in profile.Parameters)
            {
                if (parameter.Id == parameterId)
                {
                    if (profile.GetConversion(parameter).Units == conversionUnits)
                    {
                        return;
                    }
                }
            }
            Assert.Fail("Selected parameters does not contain " + parameterId + " / " + conversionUnits);
        }
    }
}
