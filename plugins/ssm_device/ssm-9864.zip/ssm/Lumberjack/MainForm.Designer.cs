namespace NateW.Ssm.Lumberjack
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabs = new System.Windows.Forms.TabControl();
            this.controlTab = new System.Windows.Forms.TabPage();
            this.folderButton = new System.Windows.Forms.Button();
            this.folderLabel = new System.Windows.Forms.Label();
            this.newButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.connectButton = new System.Windows.Forms.Button();
            this.serialPorts = new System.Windows.Forms.ListBox();
            this.profiles = new System.Windows.Forms.ListBox();
            this.saveAsButton = new System.Windows.Forms.Button();
            this.openButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.logAlways = new System.Windows.Forms.RadioButton();
            this.logOff = new System.Windows.Forms.RadioButton();
            this.logSpaceBar = new System.Windows.Forms.RadioButton();
            this.logClosedLoop = new System.Windows.Forms.RadioButton();
            this.logOpenLoop = new System.Windows.Forms.RadioButton();
            this.logDefogger = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.ecuIdentifierLabel = new System.Windows.Forms.Label();
            this.statusText = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.parametersTab = new System.Windows.Forms.TabPage();
            this.parameterGrid = new System.Windows.Forms.DataGridView();
            this.ParamEnabled = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.ParamName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ParamUnits = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dashboardTab = new System.Windows.Forms.TabPage();
            this.canvas = new System.Windows.Forms.Label();
            this.tabs.SuspendLayout();
            this.controlTab.SuspendLayout();
            this.parametersTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.parameterGrid)).BeginInit();
            this.dashboardTab.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabs
            // 
            this.tabs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabs.Controls.Add(this.controlTab);
            this.tabs.Controls.Add(this.parametersTab);
            this.tabs.Controls.Add(this.dashboardTab);
            this.tabs.Location = new System.Drawing.Point(2, 2);
            this.tabs.Name = "tabs";
            this.tabs.SelectedIndex = 0;
            this.tabs.Size = new System.Drawing.Size(612, 432);
            this.tabs.TabIndex = 0;
            // 
            // controlTab
            // 
            this.controlTab.Controls.Add(this.folderButton);
            this.controlTab.Controls.Add(this.folderLabel);
            this.controlTab.Controls.Add(this.newButton);
            this.controlTab.Controls.Add(this.saveButton);
            this.controlTab.Controls.Add(this.connectButton);
            this.controlTab.Controls.Add(this.serialPorts);
            this.controlTab.Controls.Add(this.profiles);
            this.controlTab.Controls.Add(this.saveAsButton);
            this.controlTab.Controls.Add(this.openButton);
            this.controlTab.Controls.Add(this.label2);
            this.controlTab.Controls.Add(this.logAlways);
            this.controlTab.Controls.Add(this.logOff);
            this.controlTab.Controls.Add(this.logSpaceBar);
            this.controlTab.Controls.Add(this.logClosedLoop);
            this.controlTab.Controls.Add(this.logOpenLoop);
            this.controlTab.Controls.Add(this.logDefogger);
            this.controlTab.Controls.Add(this.label5);
            this.controlTab.Controls.Add(this.ecuIdentifierLabel);
            this.controlTab.Controls.Add(this.statusText);
            this.controlTab.Controls.Add(this.label3);
            this.controlTab.Controls.Add(this.label1);
            this.controlTab.Location = new System.Drawing.Point(4, 22);
            this.controlTab.Name = "controlTab";
            this.controlTab.Padding = new System.Windows.Forms.Padding(3);
            this.controlTab.Size = new System.Drawing.Size(604, 406);
            this.controlTab.TabIndex = 0;
            this.controlTab.Text = "Control";
            this.controlTab.UseVisualStyleBackColor = true;
            // 
            // folderButton
            // 
            this.folderButton.Location = new System.Drawing.Point(3, 219);
            this.folderButton.Name = "folderButton";
            this.folderButton.Size = new System.Drawing.Size(110, 23);
            this.folderButton.TabIndex = 19;
            this.folderButton.Text = "Set &Folder";
            this.folderButton.UseVisualStyleBackColor = true;
            this.folderButton.Click += new System.EventHandler(this.folderButton_Click);
            // 
            // directoryLabel
            // 
            this.folderLabel.AutoSize = true;
            this.folderLabel.Location = new System.Drawing.Point(3, 203);
            this.folderLabel.Name = "directoryLabel";
            this.folderLabel.Size = new System.Drawing.Size(108, 13);
            this.folderLabel.TabIndex = 18;
            this.folderLabel.Text = "Logs will be saved in:";
            // 
            // newButton
            // 
            this.newButton.Location = new System.Drawing.Point(3, 134);
            this.newButton.Name = "newButton";
            this.newButton.Size = new System.Drawing.Size(110, 23);
            this.newButton.TabIndex = 11;
            this.newButton.Text = "&New Profile";
            this.newButton.UseVisualStyleBackColor = true;
            this.newButton.Click += new System.EventHandler(this.newButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.saveButton.Enabled = false;
            this.saveButton.Location = new System.Drawing.Point(169, 134);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(110, 23);
            this.saveButton.TabIndex = 13;
            this.saveButton.Text = "&Save Profile";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // connectButton
            // 
            this.connectButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.connectButton.Location = new System.Drawing.Point(315, 134);
            this.connectButton.Name = "connectButton";
            this.connectButton.Size = new System.Drawing.Size(95, 23);
            this.connectButton.TabIndex = 15;
            this.connectButton.Text = "&Reconnect";
            this.connectButton.UseVisualStyleBackColor = true;
            this.connectButton.Click += new System.EventHandler(this.connectButton_Click);
            // 
            // serialPorts
            // 
            this.serialPorts.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.serialPorts.FormattingEnabled = true;
            this.serialPorts.Location = new System.Drawing.Point(315, 33);
            this.serialPorts.Name = "serialPorts";
            this.serialPorts.Size = new System.Drawing.Size(145, 95);
            this.serialPorts.TabIndex = 3;
            this.serialPorts.SelectedIndexChanged += new System.EventHandler(this.serialPorts_SelectedIndexChanged);
            // 
            // profiles
            // 
            this.profiles.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.profiles.FormattingEnabled = true;
            this.profiles.Location = new System.Drawing.Point(3, 33);
            this.profiles.Name = "profiles";
            this.profiles.Size = new System.Drawing.Size(276, 95);
            this.profiles.TabIndex = 1;
            this.profiles.SelectedIndexChanged += new System.EventHandler(this.profiles_SelectedIndexChanged);
            // 
            // saveAsButton
            // 
            this.saveAsButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.saveAsButton.Enabled = false;
            this.saveAsButton.Location = new System.Drawing.Point(169, 163);
            this.saveAsButton.Name = "saveAsButton";
            this.saveAsButton.Size = new System.Drawing.Size(110, 23);
            this.saveAsButton.TabIndex = 14;
            this.saveAsButton.Text = "Save Profile &As...";
            this.saveAsButton.UseVisualStyleBackColor = true;
            this.saveAsButton.Click += new System.EventHandler(this.saveAsButton_Click);
            // 
            // openButton
            // 
            this.openButton.Enabled = false;
            this.openButton.Location = new System.Drawing.Point(3, 163);
            this.openButton.Name = "openButton";
            this.openButton.Size = new System.Drawing.Size(110, 23);
            this.openButton.TabIndex = 12;
            this.openButton.Text = "&Open Profile...";
            this.openButton.UseVisualStyleBackColor = true;
            this.openButton.Click += new System.EventHandler(this.openButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Selected &Profile";
            // 
            // logAlways
            // 
            this.logAlways.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logAlways.AutoSize = true;
            this.logAlways.Location = new System.Drawing.Point(494, 59);
            this.logAlways.Name = "logAlways";
            this.logAlways.Size = new System.Drawing.Size(99, 17);
            this.logAlways.TabIndex = 6;
            this.logAlways.Text = "&Enable Logging";
            this.logAlways.UseVisualStyleBackColor = true;
            this.logAlways.CheckedChanged += new System.EventHandler(this.logAlways_CheckedChanged);
            // 
            // logOff
            // 
            this.logOff.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logOff.AutoSize = true;
            this.logOff.Checked = true;
            this.logOff.Location = new System.Drawing.Point(494, 36);
            this.logOff.Name = "logOff";
            this.logOff.Size = new System.Drawing.Size(72, 17);
            this.logOff.TabIndex = 5;
            this.logOff.TabStop = true;
            this.logOff.Text = "&View Only";
            this.logOff.UseVisualStyleBackColor = true;
            this.logOff.CheckedChanged += new System.EventHandler(this.logOff_CheckedChanged);
            // 
            // logSpaceBar
            // 
            this.logSpaceBar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logSpaceBar.AutoSize = true;
            this.logSpaceBar.Enabled = false;
            this.logSpaceBar.Location = new System.Drawing.Point(494, 151);
            this.logSpaceBar.Name = "logSpaceBar";
            this.logSpaceBar.Size = new System.Drawing.Size(75, 17);
            this.logSpaceBar.TabIndex = 10;
            this.logSpaceBar.Text = "Space &Bar";
            this.logSpaceBar.UseVisualStyleBackColor = true;
            this.logSpaceBar.Visible = false;
            this.logSpaceBar.CheckedChanged += new System.EventHandler(this.logSpaceBar_CheckedChanged);
            // 
            // logClosedLoop
            // 
            this.logClosedLoop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logClosedLoop.AutoSize = true;
            this.logClosedLoop.Enabled = false;
            this.logClosedLoop.Location = new System.Drawing.Point(494, 128);
            this.logClosedLoop.Name = "logClosedLoop";
            this.logClosedLoop.Size = new System.Drawing.Size(84, 17);
            this.logClosedLoop.TabIndex = 9;
            this.logClosedLoop.Text = "Closed &Loop";
            this.logClosedLoop.UseVisualStyleBackColor = true;
            this.logClosedLoop.CheckedChanged += new System.EventHandler(this.logClosedLoop_CheckedChanged);
            // 
            // logOpenLoop
            // 
            this.logOpenLoop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logOpenLoop.AutoSize = true;
            this.logOpenLoop.Enabled = false;
            this.logOpenLoop.Location = new System.Drawing.Point(494, 105);
            this.logOpenLoop.Name = "logOpenLoop";
            this.logOpenLoop.Size = new System.Drawing.Size(78, 17);
            this.logOpenLoop.TabIndex = 8;
            this.logOpenLoop.Text = "Open &Loop";
            this.logOpenLoop.UseVisualStyleBackColor = true;
            this.logOpenLoop.CheckedChanged += new System.EventHandler(this.logOpenLoop_CheckedChanged);
            // 
            // logDefogger
            // 
            this.logDefogger.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logDefogger.AutoSize = true;
            this.logDefogger.Enabled = false;
            this.logDefogger.Location = new System.Drawing.Point(494, 82);
            this.logDefogger.Name = "logDefogger";
            this.logDefogger.Size = new System.Drawing.Size(69, 17);
            this.logDefogger.TabIndex = 7;
            this.logDefogger.Text = "&Defogger";
            this.logDefogger.UseVisualStyleBackColor = true;
            this.logDefogger.CheckedChanged += new System.EventHandler(this.logDefogger_CheckedChanged);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(491, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Logging &Control";
            // 
            // ecuIdentifierLabel
            // 
            this.ecuIdentifierLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ecuIdentifierLabel.AutoSize = true;
            this.ecuIdentifierLabel.Location = new System.Drawing.Point(312, 139);
            this.ecuIdentifierLabel.Name = "ecuIdentifierLabel";
            this.ecuIdentifierLabel.Size = new System.Drawing.Size(81, 13);
            this.ecuIdentifierLabel.TabIndex = 7;
            this.ecuIdentifierLabel.Text = "Not connected.";
            // 
            // statusText
            // 
            this.statusText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.statusText.Location = new System.Drawing.Point(3, 279);
            this.statusText.Multiline = true;
            this.statusText.Name = "statusText";
            this.statusText.ReadOnly = true;
            this.statusText.Size = new System.Drawing.Size(593, 119);
            this.statusText.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 263);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Debug messages:";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(312, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "&Communication Port";
            // 
            // parametersTab
            // 
            this.parametersTab.Controls.Add(this.parameterGrid);
            this.parametersTab.Location = new System.Drawing.Point(4, 22);
            this.parametersTab.Name = "parametersTab";
            this.parametersTab.Padding = new System.Windows.Forms.Padding(3);
            this.parametersTab.Size = new System.Drawing.Size(604, 406);
            this.parametersTab.TabIndex = 2;
            this.parametersTab.Text = "Parameters";
            this.parametersTab.UseVisualStyleBackColor = true;
            // 
            // parameterGrid
            // 
            this.parameterGrid.AllowUserToAddRows = false;
            this.parameterGrid.AllowUserToDeleteRows = false;
            this.parameterGrid.AllowUserToResizeColumns = false;
            this.parameterGrid.AllowUserToResizeRows = false;
            this.parameterGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.parameterGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.parameterGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ParamEnabled,
            this.ParamName,
            this.ParamUnits});
            this.parameterGrid.Location = new System.Drawing.Point(9, 6);
            this.parameterGrid.Name = "parameterGrid";
            this.parameterGrid.ShowEditingIcon = false;
            this.parameterGrid.Size = new System.Drawing.Size(587, 392);
            this.parameterGrid.TabIndex = 16;
            this.parameterGrid.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.parameterGrid_CellValueChanged);
            // 
            // ParamEnabled
            // 
            this.ParamEnabled.FillWeight = 1F;
            this.ParamEnabled.Frozen = true;
            this.ParamEnabled.HeaderText = "Enabled";
            this.ParamEnabled.MinimumWidth = 20;
            this.ParamEnabled.Name = "ParamEnabled";
            this.ParamEnabled.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ParamEnabled.Width = 50;
            // 
            // ParamName
            // 
            this.ParamName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ParamName.HeaderText = "Name";
            this.ParamName.Name = "ParamName";
            this.ParamName.ReadOnly = true;
            // 
            // ParamUnits
            // 
            this.ParamUnits.FillWeight = 1F;
            this.ParamUnits.HeaderText = "Units";
            this.ParamUnits.MinimumWidth = 50;
            this.ParamUnits.Name = "ParamUnits";
            this.ParamUnits.Width = 150;
            // 
            // dashboardTab
            // 
            this.dashboardTab.Controls.Add(this.canvas);
            this.dashboardTab.Location = new System.Drawing.Point(4, 22);
            this.dashboardTab.Name = "dashboardTab";
            this.dashboardTab.Padding = new System.Windows.Forms.Padding(3);
            this.dashboardTab.Size = new System.Drawing.Size(604, 406);
            this.dashboardTab.TabIndex = 1;
            this.dashboardTab.Text = "Display";
            this.dashboardTab.UseVisualStyleBackColor = true;
            // 
            // canvas
            // 
            this.canvas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.canvas.Location = new System.Drawing.Point(3, 3);
            this.canvas.Name = "canvas";
            this.canvas.Size = new System.Drawing.Size(598, 400);
            this.canvas.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 434);
            this.Controls.Add(this.tabs);
            this.Name = "MainForm";
            this.Text = "Lumberjack";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.tabs.ResumeLayout(false);
            this.controlTab.ResumeLayout(false);
            this.controlTab.PerformLayout();
            this.parametersTab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.parameterGrid)).EndInit();
            this.dashboardTab.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabs;
        private System.Windows.Forms.TabPage controlTab;
        private System.Windows.Forms.TabPage dashboardTab;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox statusText;
        private System.Windows.Forms.Label ecuIdentifierLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton logClosedLoop;
        private System.Windows.Forms.RadioButton logOpenLoop;
        private System.Windows.Forms.RadioButton logDefogger;
        private System.Windows.Forms.RadioButton logSpaceBar;
        private System.Windows.Forms.RadioButton logAlways;
        private System.Windows.Forms.RadioButton logOff;
        private System.Windows.Forms.TabPage parametersTab;
        private System.Windows.Forms.DataGridView parameterGrid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button saveAsButton;
        private System.Windows.Forms.Button openButton;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ParamEnabled;
        private System.Windows.Forms.DataGridViewTextBoxColumn ParamName;
        private System.Windows.Forms.DataGridViewComboBoxColumn ParamUnits;
        private System.Windows.Forms.Label canvas;
        private System.Windows.Forms.ListBox profiles;
        private System.Windows.Forms.ListBox serialPorts;
        private System.Windows.Forms.Button connectButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button newButton;
        private System.Windows.Forms.Button folderButton;
        private System.Windows.Forms.Label folderLabel;
    }
}

