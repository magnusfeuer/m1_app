///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// MainForm.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.IO;
using System.IO.Ports;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using NateW.Ssm.Properties;

namespace NateW.Ssm.Lumberjack
{
    public partial class MainForm
    {
        void IUserInterface.Invoke(ThreadStart code)
        {
            base.Invoke(code);
        }

        void IUserInterface.SetTitle(string title)
        {
            this.Text = title;
        }

        void IUserInterface.SetLogMode(LogMode mode)
        {
            if (mode == LogMode.Constant)
            {
                this.logAlways.Checked = true;
            }
            else if (mode == LogMode.Defogger)
            {
                this.logDefogger.Checked = true;
            }
        }

        void IUserInterface.AddSerialPort(string name)
        {
            this.serialPorts.Items.Add(name);
        }

        bool IUserInterface.SerialPortListContains(string name)
        {
            return this.serialPorts.Items.Contains(name);
        }

        string IUserInterface.GetSelectedSerialPort()
        {
            return (string) this.serialPorts.SelectedItem;
        }

        void IUserInterface.SelectSerialPort(string name)
        {
            this.serialPorts.SelectedItem = name;
        }

        void IUserInterface.AddProfile(string path)
        {
            foreach (PathDisplayAdaptor adaptor in this.profiles.Items)
            {
                if (adaptor.Equals(path))
                {
                    return;
                }
            }

            PathDisplayAdaptor newAdaptor = new PathDisplayAdaptor(path);
            this.profiles.Items.Add(newAdaptor);
        }

        void IUserInterface.SelectProfile(string path)
        {
            for (int i = 0; i < this.profiles.Items.Count; i++)
            {
                PathDisplayAdaptor adaptor = (PathDisplayAdaptor) this.profiles.Items[i];
                if (adaptor.Equals(path))
                {
                    this.profiles.SelectedIndex = i;
                    return;
                }
            }
        }

        string IUserInterface.GetSelectedProfile()
        {
            PathDisplayAdaptor adaptor = (PathDisplayAdaptor) this.profiles.SelectedItem;
            if (adaptor == null)
            {
                return null;
            }

            return adaptor.Path;
        }

        IEnumerable<PathDisplayAdaptor> IUserInterface.Profiles
        {
            get
            {
                foreach (PathDisplayAdaptor adaptor in this.profiles.Items)
                {
                    yield return adaptor;
                }
            }
        }

        DialogResult IUserInterface.PromptToSaveProfileBeforeChanging(string path)
        {
            DialogResult result = MessageBox.Show(
                                   this,
                                   "The logging profile has changed.  Would you like to save it before changing profiles?",
                                   path,
                                   MessageBoxButtons.YesNoCancel);
            return result;
        }

        DialogResult IUserInterface.PromptForLoggingFolder(out string path)
        {
            //string initialPath = Environment.CurrentDirectory;

            Shell32.ShellClass shell = new Shell32.ShellClass();
            Shell32.Folder2 folder = (Shell32.Folder2)shell.BrowseForFolder(
                this.Handle.ToInt32(),
                "Select Folder...",
                0, // Options
                this.lumberjack.Settings.LogFolderPath
            );
            path = folder.Self.Path;
            this.folderLabel.Text = path;
            
            /*
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.CheckPathExists = true;
            dialog.InitialDirectory = Settings.Default.LogFolderPath;
            dialog.ValidateNames = true;
            DialogResult result = dialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                string path = dialog.FileName;
                path = Path.GetDirectoryName(path);
                Settings.Default.LogFolderPath = path;
            }
            */
            //Environment.CurrentDirectory = initialPath;
            return DialogResult.OK; // TODO: really?
        }
                
        void IUserInterface.ShowLogFolder(string path)
        {
            this.folderLabel.Text = "Save logs to: " + path;
        }

        bool IUserInterface.SaveButtonEnabled { set { this.saveButton.Enabled = value; } }

        void IUserInterface.RenderLogEntry(LogEventArgs args)
        {
            if (this.IsDisposed)
            {
                return;
            }

            if (tabs.SelectedTab == this.controlTab)
            {
                this.RenderEntryToStatusControl(args);
            }
            else if (tabs.SelectedTab == this.dashboardTab)
            {
                this.RenderEntryToDashboard(args);
            }
        }

        void IUserInterface.RenderError(Exception ex)
        {
            Trace("LogError");

            if (this.IsDisposed)
            {
                return;
            }

            StringBuilder builder = new StringBuilder();
            do
            {
                builder.AppendLine(ex.ToString());
                builder.AppendLine("Inner Exception: ");
                ex = ex.InnerException;
            } while (ex != null);
            builder.Append("(no inner exception)");

            this.statusText.Text = builder.ToString();
        }

        void IUserInterface.ConnectionStateChanged(bool connected)
        {
            Trace("ConnectionStateChanged " + connected);

            if (connected)
            {
                this.logAlways.Enabled = true;
                string ecuIdentifier = this.lumberjack.EcuIdentifier;
                this.ecuIdentifierLabel.Text = "Connected to " + ecuIdentifier;
                this.statusText.Text = "Connected.";
            }
            else
            {
                this.ecuIdentifierLabel.Text = "Not connected";
            }

            this.logOff.Checked = true;

            this.connectButton.Visible = !connected;
            this.ecuIdentifierLabel.Visible = connected;

            this.profiles.Enabled = connected;
            this.openButton.Enabled = connected;
            this.saveAsButton.Enabled = connected;

            this.logAlways.Enabled = connected;
            this.logDefogger.Enabled = connected;
            this.logClosedLoop.Enabled = connected;
            this.logOpenLoop.Enabled = connected;
            
            connected = false;
            this.logSpaceBar.Enabled = connected;
        }

        DialogResult IUserInterface.ShowOpenDialog(out string path)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.AddExtension = true;
            dialog.DefaultExt = SsmLogger.DefaultProfileExtension;
            dialog.Filter = SsmLogger.FileDialogFilterString;
            DialogResult result = dialog.ShowDialog(this);
            path = dialog.FileName;
            return result;
        }

        DialogResult IUserInterface.ShowSaveAsDialog(out string path)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.AddExtension = true;
            dialog.DefaultExt = SsmLogger.DefaultProfileExtension;
            dialog.Filter = SsmLogger.FileDialogFilterString;
            DialogResult result = dialog.ShowDialog(this);
            path = dialog.FileName;
            return result;
        }

        void IUserInterface.PopulateParameterList(SsmParameterDatabase database)
        {
            Trace("PopulateParameterList");

            this.parameterGrid.Rows.Clear();

            foreach (SsmParameter parameter in database.Parameters)
            {
                DataGridViewRow row = new DataGridViewRow();
                row.CreateCells(this.parameterGrid);
                row.Cells[(int)GridColumns.Enabled].Value = false;
                row.Cells[(int)GridColumns.Parameter].Value = parameter;

                ((DataGridViewComboBoxCell)row.Cells[(int)GridColumns.Conversions]).DisplayMember = "Units";
                foreach (Conversion conversion in parameter.Conversions)
                {
                    ((DataGridViewComboBoxCell)row.Cells[(int)GridColumns.Conversions]).Items.Add(conversion);
                }
                ((DataGridViewComboBoxCell)row.Cells[(int)GridColumns.Conversions]).Value = parameter.Conversions[0];

                this.parameterGrid.Rows.Add(row);
            }
        }

        void IUserInterface.GetNewProfileSettings(LogProfile profile)
        {
            Trace("UpdateProfile");

            foreach (DataGridViewRow row in this.parameterGrid.Rows)
            {
                if ((bool)row.Cells[(int)GridColumns.Enabled].Value)
                {
                    profile.Add(
                        (SsmParameter)row.Cells[(int)GridColumns.Parameter].Value,
                        (Conversion)row.Cells[(int)GridColumns.Conversions].Value);
                }
            }
        }

        void IUserInterface.ShowNewProfileSettings(LogProfile profile)
        {
            Trace("ShowNewProfileSettings");
                        
            foreach (DataGridViewRow row in this.parameterGrid.Rows)
            {
                row.Cells[(int)GridColumns.Enabled].Value = false;

                foreach (SsmParameter parameter in profile.Parameters)
                {
                    SsmParameter rowParameter = (SsmParameter)row.Cells[(int)GridColumns.Parameter].Value;
                    if (rowParameter.Id == parameter.Id)
                    {
                        row.Cells[(int)GridColumns.Enabled].Value = true;
                        foreach (Conversion conversion in ((DataGridViewComboBoxCell)row.Cells[(int)GridColumns.Conversions]).Items)
                        {
                            if (conversion.Units == profile.GetConversion(parameter).Units)
                            {
                                ((DataGridViewComboBoxCell)row.Cells[(int)GridColumns.Conversions]).Value = profile.GetConversion(parameter);
                            }
                        }
                    }
                }
            }
        }
    }
}