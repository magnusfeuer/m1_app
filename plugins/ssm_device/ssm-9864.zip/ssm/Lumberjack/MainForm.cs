///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// MainForm.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.IO;
using System.IO.Ports;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using NateW.Ssm.Properties;

namespace NateW.Ssm.Lumberjack
{
    public partial class MainForm : Form, IUserInterface
    {
        private Lumberjack lumberjack;
        private Bitmap backbuffer;
        private float lineHeight = 30;

        private enum GridColumns : int
        {
            Enabled,
            Parameter,
            Conversions
        }

        public LogMode StartMode
        {
            set { this.lumberjack.StartMode = value; }
        }

        public string StartProfile
        {
            set { this.lumberjack.StartProfile = value; }
        }

        public string StartPort
        {
            set { this.lumberjack.StartPort = value; }
        }

        public MainForm()
        {
            this.lumberjack = new Lumberjack(this);
            InitializeComponent();
        }

        #region GUI Event Handlers

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.RunUnderExceptionHandler(
                delegate
                {
                    Trace("MainForm_Load");
                    if (string.Compare(Environment.GetEnvironmentVariable("ComputerName"), "Monolith", true) == 0)
                    {
                        this.lumberjack.Settings.Reset();
                    }

                    this.lumberjack.Load();

                    try
                    {
                        if (this.lumberjack.Settings.MainFormMaximized)
                        {
                            this.WindowState = FormWindowState.Maximized;
                        }
                        else
                        {
                            // TODO: is there a way to test if this setting exists w/o try/catch? 
                            Rectangle rect = this.lumberjack.Settings.MainFormRectangle;
                            this.Left = rect.Left;
                            this.Top = rect.Top;
                            this.Width = rect.Width;
                            this.Height = rect.Height;
                        }
                    }
                    catch (System.NullReferenceException)
                    {
                    }
                });
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Trace("MainForm_FormClosing");

            bool cancel = false;
            this.lumberjack.Closing(ref cancel);
            e.Cancel = cancel;
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Trace("MainForm_FormClosed");
            
            bool maximized = this.WindowState == FormWindowState.Maximized;
            this.lumberjack.Settings.MainFormMaximized = maximized;
            if (!maximized)
            {
                Rectangle rect = new Rectangle(this.Left, this.Top, this.Width, this.Height);
                this.lumberjack.Settings.MainFormRectangle = rect;
            }

            this.lumberjack.Closed();
        }

        private void serialPorts_SelectedIndexChanged(object sender, EventArgs e)
        {
            RunUnderExceptionHandler(
                delegate
                {
                    Trace("serialPorts_SelectedIndexChanged");

                    this.lumberjack.ChangeSerialPort();
                });
        }

        private void profiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            Trace("profiles_SelectedIndexChanged");

            this.RunUnderExceptionHandler(delegate
            {
                this.lumberjack.SelectedProfileChanged();
            });
        }

        private void logOff_CheckedChanged(object sender, EventArgs e)
        {
            Trace("logOff_CheckedChanged: " + this.logOff.Checked);
            this.lumberjack.LogMode = LogMode.DisplayOnly;
        }

        private void logAlways_CheckedChanged(object sender, EventArgs e)
        {
            Trace("logAlways_CheckedChanged: " + this.logAlways.Checked);

            this.lumberjack.LogMode = LogMode.Constant;
            return;
        }

        private void logDefogger_CheckedChanged(object sender, EventArgs e)
        {
            Trace("logAlways_CheckedChanged: " + this.logAlways.Checked);

            this.lumberjack.LogMode = LogMode.Defogger;
            return;
        }

        private void logOpenLoop_CheckedChanged(object sender, EventArgs e)
        {
            Trace("logAlways_CheckedChanged: " + this.logAlways.Checked);

            this.lumberjack.LogMode = LogMode.OpenLoop;
            return;
        }

        private void logClosedLoop_CheckedChanged(object sender, EventArgs e)
        {
            Trace("logAlways_CheckedChanged: " + this.logAlways.Checked);

            this.lumberjack.LogMode = LogMode.ClosedLoop;
            return;
        }

        private void logSpaceBar_CheckedChanged(object sender, EventArgs e)
        {
            Trace("logAlways_CheckedChanged: " + this.logAlways.Checked);

            this.lumberjack.LogMode = LogMode.SpaceBar;
            return;
        }

        private void parameterGrid_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            Trace("parameterGrid_CellValueChanged");
            this.lumberjack.SelectedProfileSettingsChanged();
        }

        private void connectButton_Click(object sender, EventArgs e)
        {
            this.RunUnderExceptionHandler(delegate
            {
                Trace("connectButton_Click");
                this.lumberjack.Reconnect();
            });
        }

        private void newButton_Click(object sender, EventArgs e)
        {
            Trace("newButton_Click");
            this.lumberjack.ProfileNew();
        }

        private void openButton_Click(object sender, EventArgs e)
        {
            this.RunUnderExceptionHandler(delegate
            {
                Trace("openButton_Click");
                this.lumberjack.ProfileOpen();
            });
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            Trace("SaveButton_Click");
            this.lumberjack.ProfileSave();
        }

        private void saveAsButton_Click(object sender, EventArgs e)
        {
            this.RunUnderExceptionHandler(delegate
            {
                Trace("saveAsButton_Click");
                this.lumberjack.ProfileSaveAs();
            });
        }

        private void folderButton_Click(object sender, EventArgs e)
        {
            Trace("FolderButton_Click");
            this.lumberjack.SetLoggingFolder();
        }

        #endregion

        #region Private Methods

        private void RunUnderExceptionHandler(VoidVoid operation)
        {
            try
            {
                operation();
                this.SetError(operation.Method.Name, null);
            }
            catch (Exception ex)
            {
                this.SetError(operation.Method.Name, ex);
            }
        }

        private void SetError(string action, Exception ex)
        {
            this.statusText.Invoke(new ThreadStart(
                delegate
                {
                    Trace("SetError");
                    if (ex == null)
                    {
                        this.statusText.Text =
                            action +
                            Environment.NewLine +
                            "Succeeded";
                    }
                    else
                    {
                        this.statusText.Text =
                            action +
                            Environment.NewLine +
                            ex.ToString();
                    }
                }));
        }
        
        private void RenderEntryToStatusControl(LogEventArgs args)
        {
            StringBuilder builder = new StringBuilder(200);
            DateTime now = DateTime.Now;
            builder.Append(now.ToString("yyyy-MM-dd T hh:mm:ss:fff"));
            builder.AppendLine();

            foreach (LogColumn column in args.Row.Columns)
            {
                builder.Append(column.Parameter.Name);
                builder.Append(": ");
                builder.Append(column.Value);
                builder.AppendLine();
            }
            this.statusText.Text = builder.ToString();
        }

        private void RenderEntryToDashboard(LogEventArgs args)
        {
            if ((this.backbuffer == null) ||
                (this.backbuffer.Width != this.canvas.ClientSize.Width) ||
                (this.backbuffer.Height != this.canvas.ClientSize.Height))
            {
                this.backbuffer = new Bitmap(this.canvas.ClientSize.Width, this.canvas.ClientSize.Height);
            }

            using (Graphics offscreen = Graphics.FromImage(this.backbuffer))
            {   
                Font font = new Font(new FontFamily("Arial"), lineHeight - 2, GraphicsUnit.Pixel);
                const int pseudoParameterCount = 2;
                int lines = args.Row.Columns.Count + pseudoParameterCount;                
                this.lineHeight = Math.Min (lineHeight, (float)this.backbuffer.Height / (float) lines);
                SizeF valueSize = offscreen.MeasureString("XXXXXXX", font);
                float divider = this.Width - valueSize.Width;
                float maxWidth = 0;

                offscreen.FillRectangle(Brushes.White, 0, 0, this.backbuffer.Width, this.backbuffer.Height);

                for (int i = 0; i < lines; i++)
                {
                    float top = i * lineHeight;
                        
                    if (i % 2 == 1)
                    {
                        offscreen.FillRectangle(
                            Brushes.LightGray,
                            0,
                            top, 
                            this.backbuffer.Width, 
                            lineHeight);
                    }

                    string name;
                    string value;
                    
                    if (i == 0)
                    {
                        DateTime now = DateTime.Now;
                        name = "Clock Time";
                        value = now.ToString("hh:mm");
                    }
                    else if (i == 1)
                    {
                        TimeSpan elapsedTime = DateTime.Now.Subtract(this.lumberjack.LogStartTime);
                        name = "Elapsed Time";
                        value = ((int)elapsedTime.TotalMilliseconds).ToString();
                    }
                    else
                    {
                        int column = i - pseudoParameterCount;
                        name = args.Row.Columns[column].Parameter.Name;
                        value = args.Row.Columns[column].Value;
                    }

                    SizeF nameSize = offscreen.MeasureString(name, font);
                    offscreen.DrawString(
                        name,
                        font,
                        Brushes.Black, 
                        divider - (nameSize.Width + 2),
                        top + 1);

                    offscreen.DrawString(
                        value,
                        font,
                        Brushes.Black,
                        divider + 1,
                        top + 1);
                    maxWidth = Math.Max(maxWidth, nameSize.Width + valueSize.Width);
                }

                float newLineHeight = lineHeight * (backbuffer.Width / maxWidth);
                lineHeight += (float) 0.1 * (newLineHeight - lineHeight);

                using (Graphics graphics = this.canvas.CreateGraphics())
                {
                    graphics.DrawImageUnscaled(this.backbuffer, 0, 0);
                }
            }
        }

        private void Trace(string s)
        {
            Debug.WriteLine(s);
        }

        #endregion
    }
}