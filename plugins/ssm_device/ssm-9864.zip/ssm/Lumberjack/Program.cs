///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// Program.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.Text;
using System.Collections.Generic;
using System.Windows.Forms;

namespace NateW.Ssm.Lumberjack
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            MainForm form = new MainForm();

            if (!Program.ParseArgs(form, args))
            {
                Usage();
                return;
            }

            if (args.Length == 3)
            {

                form.StartProfile = args[0];
            }

            Application.Run(form);
        }

        private static bool ParseArgs(MainForm form, string[] args)
        {
            if (args.Length == 0)
            {
                return true;
            }
            else if (args.Length == 3)
            {
                if (args[0] == "always")
                {
                    form.StartMode = LogMode.Constant;
                    form.StartPort = args[1];
                    form.StartProfile = args[2];
                    return true;
                }
                else if (args[0] == "defogger")
                {
                    form.StartMode = LogMode.Defogger;
                    form.StartPort = args[1];
                    form.StartProfile = args[2];
                    return true;
                }
                return false;
            }

            return false;
        }

        private static void Usage()
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Usage:");
            builder.AppendLine("Lumberjack.exe");
            builder.AppendLine("Open the window, wait for you to choose a port and profile");
            builder.AppendLine();
            
            builder.AppendLine("Lumberjack.exe always <COMx> <whatever.profile>");
            builder.AppendLine("Start logging with the given profile and COM port");
            builder.AppendLine();

            builder.AppendLine("Lumberjack.exe defogger <COMx> <whatever.profile>");
            builder.AppendLine("Defogger-controlled logging with the given profile and COM port");
            builder.AppendLine();
            MessageBox.Show(builder.ToString());
        }
    }
}