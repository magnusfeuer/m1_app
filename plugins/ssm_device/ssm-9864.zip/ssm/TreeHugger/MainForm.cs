using System;
using System.Configuration;
using System.IO;
using System.IO.Ports;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using NateW.Ssm;

namespace NateW.Ssm.TreeHugger
{
    /// <summary>
    /// Main window
    /// </summary>
    public partial class MainForm : Form
    {
        /// <summary>
        /// Command-line arguments (passed from Main)
        /// </summary>
        string[] args;

        /// <summary>
        /// Serial port for the ECU connection
        /// </summary>
        SerialPort port;

        /// <summary>
        /// Logger to pull data from the ECU
        /// </summary>
        SsmLogger logger;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public MainForm(string[] args)
        {
            this.args = args;
            InitializeComponent();
        }

        /// <summary>
        /// Invoked once before the form is displayed
        /// </summary>
        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.SetBounds();
                Stream stream = this.GetDataStream();
                this.InitializeLogger(stream);
                this.StartLogging();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                this.Close();
            }
        }

        /// <summary>
        /// Set the Form's position and size
        /// </summary>
        private void SetBounds()
        {
            int left = int.Parse(ConfigurationManager.AppSettings["Left"]);
            int top = int.Parse(ConfigurationManager.AppSettings["Top"]);
            int width = int.Parse(ConfigurationManager.AppSettings["Width"]);
            int height = int.Parse(ConfigurationManager.AppSettings["Height"]);
            this.SetBounds(left, top, width, height);
        }

        /// <summary>
        /// Get the stream from which to read ECU data
        /// </summary>
        private Stream GetDataStream()
        {
            string portName = ConfigurationManager.AppSettings["Port"];
            Stream stream = null;
            if (portName == "Mock ECU")
            {
                MessageBox.Show(
                    "Bogus data will be displayed." + 
                    Environment.NewLine +
                    "If you want real data, change the \"Port\" setting in" +
                    Environment.NewLine +
                    "TreeHugger.exe.config to COM1 or COM2 or whatever.");
                stream = MockEcuStream.GetInstance();
            }
            else
            {
                try
                {
                    this.port = new SerialPort(portName, 4800, Parity.None, 8);
                    this.port.Open();
                    this.port.ReadTimeout = 2000;
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        "Unable to open " + portName +
                        Environment.NewLine +
                        ex.Message);
                }
                stream = this.port.BaseStream;
            }

            return stream;
        }

        /// <summary>
        /// Initialize the logger
        /// </summary>
        private void InitializeLogger(Stream stream)
        {
            string configurationDirectory = Path.Combine(
                Environment.CurrentDirectory,
                "Configuration");
            this.logger = SsmLogger.GetInstance(configurationDirectory, stream);
            this.logger.LogEntry += this.DisplayLogEntry;

            IAsyncResult asyncResult = this.logger.BeginConnect(null, null);
            asyncResult.AsyncWaitHandle.WaitOne();
            this.logger.EndConnect(asyncResult);
        }

        /// <summary>
        /// Start logging
        /// </summary>
        private void StartLogging()
        {
            LogProfile profile = this.CreateLogProfile();
            this.logger.SetProfile(profile);
            this.logger.StartLogging();
        }

        /// <summary>
        /// Create a log profile from the application's configuration settings
        /// </summary>
        private LogProfile CreateLogProfile()
        {
            LogProfile profile = LogProfile.GetInstance();

            for (int i = 0; i < 6; i++)
            {
                string combined = ConfigurationManager.AppSettings[i.ToString()];
                string[] idAndUnits = combined.Split(',');

                if (idAndUnits.Length != 2)
                {
                    throw new ApplicationException("Parameter " + i.ToString() + 
                        "is not of the form \"P12,units\"." + Environment.NewLine +
                        "Please fix this in TreeHugger.exe.config and try again");
                }

                string id = idAndUnits[0];
                string units = idAndUnits[1];

                this.AddParameter(profile, id, units);
            }

            return profile;
        }

        /// <summary>
        /// Add a parameter to the log profile
        /// </summary>
        private void AddParameter(LogProfile profile, string id, string units)
        {
            foreach (SsmParameter parameter in this.logger.Database.Parameters)
            {
                if (parameter.Id == id)
                {
                    foreach (Conversion conversion in parameter.Conversions)
                    {
                        if (conversion.Units == units)
                        {
                            profile.Add(parameter, conversion);
                            return;
                        }
                    }

                    throw new ApplicationException(
                        "Conversion " + units + " not found for parameter " + id);
                }
            }

            throw new ApplicationException(
                "Parameter " + id + " not found.");
        }

        /// <summary>
        /// Invoked by the logger when a new packet arrives
        /// </summary>
        private void DisplayLogEntry(object sender, LogEventArgs args)
        {
            this.BeginInvoke(
                new System.Threading.ThreadStart (
                    delegate { this.DisplayLogEntry(args.Row); }));
            System.Threading.Thread.Sleep(100);
        }

        /// <summary>
        /// Draw the log entry on the screen
        /// </summary>
        private void DisplayLogEntry(LogRow row)
        {
            try
            {
                int width = this.ClientRectangle.Width;
                int height = this.ClientRectangle.Height;

                Graphics graphics = this.CreateGraphics();
                Painter painter = new Painter(graphics, width, height, row);
                painter.Paint();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
                System.Diagnostics.Debugger.Break();
            }
        }
    }
}