using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using NateW.Ssm;

namespace NateW.Ssm.Lumberjack
{
    internal class MockUserInterface : IUserInterface
    {        
        public bool SerialPortListContainsResult = false;
        public string GetSelectedSerialPortResult = Lumberjack.MockEcuPortName;
        public string GetSelectedProfileResult = @"..\..\..\Configuration\Turbo dynamics.profile";
        public IEnumerable<PathDisplayAdaptor> ProfilesResult = new PathDisplayAdaptor[0];

        public DialogResult PromptToSaveProfileBeforeChangingResult = DialogResult.OK;
        public string ShowOpenFileDialogPath = "bogus.profile";
        public DialogResult ShowOpenFileDialogResult = DialogResult.OK;
        public string ShowSaveAsFileDialogPath = "bogus.profile";
        public DialogResult ShowSaveAsFileDialogResult = DialogResult.OK;
        public string PromptForLoggingFolderPath = "bogus.directory";
        public DialogResult PromptForLoggingFolderResult = DialogResult.OK;

        private DateTime created;
        private Lumberjack lumberjack;
        private StringBuilder builder = new StringBuilder();

        public Lumberjack Lumberjack
        {
            set
            {
                this.lumberjack = value;
            }
        }

        public MockUserInterface()
        {
            this.created = DateTime.Now;
            this.RecordEvent("MockUserInterface Constructor");
        }

        private void RecordEvent(string message)
        {
            this.builder.AppendLine(message);
            Console.WriteLine(message);
        }

        public override string ToString()
        {
            return this.builder.ToString();
        }

        public void Invoke(ThreadStart code)
        {
            this.RecordEvent("Invoke: " + code.Method.Name);
            code();
        }

        public void SetTitle(string title)
        {
            this.RecordEvent("SetTitle: " + title);
        }

        public void SetLogMode(LogMode mode)
        {
            this.RecordEvent("SetLogMode: " + mode.ToString());
        }

        public void AddSerialPort(string name)
        {
            this.RecordEvent("AddSerialPort: " + name);
        }

        public bool SerialPortListContains(string name)
        {
            return this.SerialPortListContainsResult;
        }

        public void SelectSerialPort(string name)
        {
            this.RecordEvent("SelectSerialPort: " + name);
            this.GetSelectedSerialPortResult = name;
            this.lumberjack.ChangeSerialPort();
        }

        public string GetSelectedSerialPort()
        {
            return this.GetSelectedSerialPortResult;
        }

        public void AddProfile(string path)
        {
            this.RecordEvent("AddProfile: " + path);
        }

        public void SelectProfile(string path)
        {
            this.RecordEvent("SelectProfile: " + path);
        }

        public string GetSelectedProfile()
        {
            return this.GetSelectedProfileResult;
        }

        public IEnumerable<PathDisplayAdaptor> Profiles
        {
            get
            {
                this.RecordEvent("get_Profiles");
                return ProfilesResult;
            }
        }

        public DialogResult PromptToSaveProfileBeforeChanging(string path)
        {
            this.RecordEvent("PromptToSaveProfileBeforeChanging: " + path);
            return PromptToSaveProfileBeforeChangingResult;
        }

        public void ShowLogFolder(string path)
        {
            this.RecordEvent("ShowLogFolder: " + path);
        }

        public bool SaveButtonEnabled
        { 
            set
            {
                this.RecordEvent("SaveButtonEnabled: " + value);
            }
        }

        public void ConnectionStateChanged(bool connected)
        {
            this.RecordEvent("ConnectionStateChanged: " + connected);
        }

        public void RenderLogEntry(LogEventArgs args)
        {
            Thread.Sleep(3);
            this.RecordEvent("RenderLogEntry: " + args.ToString() + " mui created: " + this.created.Millisecond);
        }

        public void RenderError(Exception exception)
        {
            this.RecordEvent("RenderLogError: " + exception.Message);
        }

        public DialogResult ShowOpenDialog(out string path)
        {
            this.RecordEvent("ShowOpenFileDialog");
            path = ShowOpenFileDialogPath;
            return ShowOpenFileDialogResult;
        }

        public DialogResult ShowSaveAsDialog(out string path)
        {
            this.RecordEvent("ShowSaveAsFileDialog");
            path = ShowSaveAsFileDialogPath;
            return ShowSaveAsFileDialogResult;
        }

        public DialogResult PromptForLoggingFolder(out string path)
        {
            this.RecordEvent("PromptForLoggingFolder");
            path = PromptForLoggingFolderPath;
            return PromptForLoggingFolderResult;
        }

        public void PopulateParameterList(SsmParameterDatabase database)
        {
            this.RecordEvent("PopulateParameterList");
        }

        public void GetNewProfileSettings(LogProfile profile)
        {
            this.RecordEvent("GetNewProfileSettings");
        }

        public void ShowNewProfileSettings(LogProfile profile)
        {
            this.RecordEvent("ShowNewProfileSettings");
        }
    }
}
