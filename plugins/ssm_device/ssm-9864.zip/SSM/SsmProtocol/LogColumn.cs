///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// LogColumn.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading;

namespace NateW.Ssm
{
    /// <summary>
    /// Represents a column in a log record
    /// </summary>
    public class LogColumn
    {
        /// <summary>
        /// The parameter logged in this column
        /// </summary>
        private SsmParameter parameter;

        /// <summary>
        /// The conversion to apply to the raw data for this column
        /// </summary>
        private Conversion conversion;

        /// <summary>
        /// If true, this column was only added because a calculated parameter depends on it
        /// </summary>
        private bool isDependency;

        /// <summary>
        /// The converted and formatted value for this column
        /// </summary>
        private string value;

        /// <summary>
        /// For calculated parameters, this maps the base parameter IDs and 
        /// conversions to the columns in which they were logged
        /// </summary>
        private Dictionary<string, LogColumn> dependencyMap;

        /// <summary>
        /// The parameter logged in this column
        /// </summary>
        public SsmParameter Parameter
        {
            [DebuggerStepThrough()]
            get { return this.parameter; }
        }

        /// <summary>
        /// The conversion to apply to the raw data for this column
        /// </summary>
        public Conversion Conversion
        {
            [DebuggerStepThrough()]
            get { return this.conversion; }
        }

        /// <summary>
        /// Indicates whether this column was only added because a calculated parameter depends on it
        /// </summary>
        public bool IsDependency
        {
            [DebuggerStepThrough()]
            get { return this.isDependency; }
        }

        /// <summary>
        /// Indicates whether this column is calculated from other columns
        /// </summary>
        public bool IsCalculated
        {
            [DebuggerStepThrough()]
            get { return this.DependencyMap != null; }
        }

        /// <summary>
        /// The converted and formatted value for this column
        /// </summary>
        public string Value
        {
            [DebuggerStepThrough()]
            get { return this.value; }
            [DebuggerStepThrough()]
            internal set { this.value = value; }
        }

        /// <summary>
        /// For calculated parameters, this maps the base parameter IDs and 
        /// conversions to the columns in which they were logged
        /// </summary>
        internal Dictionary<string, LogColumn> DependencyMap
        {
            [DebuggerStepThrough()]
            get { return this.dependencyMap; }
            [DebuggerStepThrough()]
            set { this.dependencyMap = value; }
        }

        /// <summary>
        /// Private constructor - use factory instead
        /// </summary>
        private LogColumn(
            SsmParameter parameter, 
            Conversion conversion, 
            bool isDependency)
        {
            if (parameter == null)
            {
                throw new ArgumentNullException("parameter");
            }

            if (conversion == null)
            {
                conversion = Conversion.Raw;
            }

            this.parameter = parameter;
            this.conversion = conversion;
            this.isDependency = isDependency;
        }

        /// <summary>
        /// Factory 
        /// </summary>
        public static LogColumn GetInstance(
            SsmParameter parameter, 
            Conversion conversion, 
            bool isDependency)
        {
            return new LogColumn(parameter, conversion, isDependency);
        }
        
        /// <summary>
        /// For debugging convenience - do not use in UI
        /// </summary>
        public override string ToString()
        {
            return this.parameter.ToString() + " " + this.conversion.ToString();
        }
    }
}
