///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// Lumberjack.cs
// Core application logic for Win32 and WinCE versions of the SSM logger
///////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.IO.Ports;
using System.Threading;
using NateW.Ssm.Applications.Properties;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Windows.Forms;

namespace NateW.Ssm.Applications
{
    public delegate void VoidVoid();

    public enum LogMode
    {
        None,
        DisplayOnly,
        Constant,
        Defogger,
        OpenLoop,
        ClosedLoop,
        Spacebar,
    }

    public partial class Lumberjack : IDisposable
    {
        public const string MockEcuPortName = "Mock ECU";
        private static string configurationDirectory;
        private IUserInterface ui;
        private SerialPort port;
        private Stream ecuStream;
        private SsmLogger logger;
        private DateTime logStartTime = DateTime.Now;
        private bool currentProfileIsChanged;
        private LogFilter logFilter;
        private bool restartLogging;
        private LogMode logMode = LogMode.DisplayOnly;
        private LogMode startMode = LogMode.None;
        private string startProfile;
        private string startPort;
        private bool ignoreProfileSettingsChangeNotifications;
        
        /// <summary>
        /// Application settings.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        public Settings Settings
        {
            get
            {
                return Settings.Default;
            }
        }

        /// <summary>
        /// ECU identifier string.
        /// </summary>
        public string EcuIdentifier
        {
            get
            {
                return this.logger.EcuIdentifier;
            }
        }

        /// <summary>
        /// SSM parameter database for the currently-connected ECU.
        /// </summary>
        public SsmParameterDatabase Database
        {
            get
            {
                return this.logger.Database;
            }
        }

        /// <summary>
        /// Time the current log started.
        /// </summary>
        public DateTime LogStartTime
        {
            get
            {
                return this.logStartTime;
            }
        }

        /// <summary>
        /// If true, the current profile has changed since it was last saved.
        /// </summary>
        internal bool CurrentProfileIsChanged
        {
            get
            {
                return this.currentProfileIsChanged;
            }
        }

        /// <summary>
        /// Construct an instance of Lumberjack with the given UI.
        /// </summary>
        /// <param name="ui">User interface.</param>
        public Lumberjack(IUserInterface ui)
        {
            this.ui = ui;
            this.Settings.Reload();
        }

        /// <summary>
        /// Finalizer.
        /// </summary>
        ~Lumberjack()
        {
            this.Dispose(false);
        }

        /// <summary>
        /// Dispose of a Lumberjack instance. (Public IDispose.Dispose implementation.)
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Implements the Dispose pattern.
        /// </summary>
        /// <param name="disposing">True if disposing, false if finalizing.</param>
        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (this.port != null)
                {
                    this.port.Dispose();
                    this.port = null;
                }
            }
        }

        /// <summary>
        /// Set the logging mode to use upon startup.
        /// </summary>
        /// <param name="value">Logging mode to use upon start.</param>
        public void SetStartupLoggingMode(LogMode value)
        {
            this.startMode = value;
        }

        /// <summary>
        /// Set the logging profile to use upon startup.
        /// </summary>
        /// <param name="value">Logging profile to use upon startup.</param>
        public void SetStartupLoggingProfile(string value)
        {
            this.startProfile = value;
        }

        /// <summary>
        /// Set the serial port to use upon startup.
        /// </summary>
        /// <param name="value">Serial port to use upon startup.</param>
        public void SetStartupPort(string value)
        {
            this.startPort = value;
        }

        /// <summary>
        /// Set the current logging mode.
        /// </summary>
        /// <param name="value">Desired logging mode.</param>
        public void SetLogMode(LogMode value)
        {
            this.logMode = value;
        }

        /// <summary>
        /// Call this when the main form loads.
        /// </summary>
        public void Load()
        {
            this.Settings.Reload();

            this.logFilter = LogFilter.GetInstance(
                this.CreateLogWriter,
                this.ShouldLog);

            this.InitializeLogFolderPath();
            this.InitializeProfileList();
            this.InitializeSerialPortList();

            if (this.startPort != null)
            {
                this.Settings.DefaultPort = this.startPort;
                this.startPort = null;
            }

            if (this.startProfile != null)
            {
                this.Settings.LastProfilePath = this.startProfile;
                this.startProfile = null;
            }

            this.ui.SelectProfile(this.Settings.LastProfilePath);
            this.ui.SelectSerialPort(this.Settings.DefaultPort);

            this.SetTitle();
        }

        /// <summary>
        /// Call this when the main form closes.
        /// </summary>
        /// <param name="cancel">If true, the Close should be aborted.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1045:DoNotPassTypesByReference", MessageId = "0#")]
        public void Closing(ref bool cancel)
        {
            if (this.currentProfileIsChanged)
            {
                if (!PromptToSaveChangedProfile())
                {
                    cancel = true;
                }
            }

            if (!cancel)
            {
                if (this.logger.IsLogging)
                {
                    cancel = true;
                    this.logger.BeginStopLogging(this.ContinueClosing, null);
                }
                else
                {
                    this.SaveProfileList();
                    this.Settings.Save();
                }
            }
        }

        /// <summary>
        /// Call this when the user selects a serial port.
        /// </summary>
        public void ChangeSerialPort()
        {            
            this.ReopenEcuInterface();
        }

        /// <summary>
        /// Call this if the user wants to reconnect to the ECU.
        /// </summary>
        /// <remarks>Shouldn't be necessary - remove before "gamma" release.</remarks>
        public void Reconnect()
        {
            this.ReopenEcuInterface();
        }

        /// <summary>
        /// Call this when the user wants to create a new profile.
        /// </summary>
        public void ProfileNew()
        {
            LogProfile empty = LogProfile.CreateInstance();
            logger.SetProfile(empty);

            this.Settings.LastProfilePath = null;

            this.ShowNewProfileSettings();
            this.ui.SelectProfile(null);
            this.ui.SetSaveButtonState(false);
            this.currentProfileIsChanged = false;
            this.SetTitle();
        }

        /// <summary>
        /// Call this when the user wants to open a new profile.
        /// </summary>
        public void ProfileOpen()
        {
            if (!this.SaveProfileIfChanged())
            {
                return;
            }

            string newPath;
            DialogResult result = this.ui.ShowOpenDialog(out newPath);
            if (result == DialogResult.OK && !string.IsNullOrEmpty(newPath))
            {
                this.ui.AddProfile(newPath);
                this.ui.SelectProfile(newPath);
            }
        }

        /// <summary>
        /// Call this when the user wants to save the current profile.
        /// </summary>
        public void ProfileSave()
        {
            if (string.IsNullOrEmpty(this.Settings.LastProfilePath))
            {
                this.ProfileSaveAs();
                return;
            }

            this.logger.SaveProfile(this.Settings.LastProfilePath);
            this.currentProfileIsChanged = false;
            this.SetTitle();
        }

        /// <summary>
        /// Call this when the user wants to save the current profile to a new file.
        /// </summary>
        public void ProfileSaveAs()
        {
            string newPath;
            DialogResult result = this.ui.ShowSaveAsDialog(out newPath);

            if (result == DialogResult.OK && !string.IsNullOrEmpty(newPath))
            {
                this.logger.SaveProfile(newPath);
                this.currentProfileIsChanged = false;

                this.ui.AddProfile(newPath);
                this.ui.SelectProfile(newPath);
                this.ui.SetSaveButtonState(true);
                this.SetTitle();
            }
        }

        /// <summary>
        /// Call this when the user selects a new profile.
        /// </summary>
        public void SelectedProfileChanged()
        {
            if (!this.SaveProfileIfChanged())
            {
                return;
            }

            string profilePath = this.ui.GetSelectedProfile();
            if (profilePath == null)
            {
                this.ui.SetSaveButtonState(false);
            }

            this.LoadProfile(profilePath);
        }

        /// <summary>
        /// Call this after the user has changed the set of parameters to log.
        /// </summary>
        public void SelectedProfileSettingsChanged()
        {
            if (this.logger == null)
            {
                return;
            }

            if (this.ignoreProfileSettingsChangeNotifications)
            {
                return;
            }

            LogProfile profile = LogProfile.CreateInstance();
            this.ui.GetNewProfileSettings(profile);
            this.ui.SetSaveButtonState(true);
            this.logger.SetProfile(profile);

            this.currentProfileIsChanged = true;
            this.SetTitle();
        }
        
        /// <summary>
        /// Call this when the user wants to select a new folder to store logs in.
        /// </summary>
        public void SetLoggingFolder()
        {
            string path;
            DialogResult result = this.ui.PromptForLoggingFolder(out path);
            if (result == DialogResult.OK)
            {
                this.Settings.LogFolderPath = path;
            }
        }

        /// <summary>
        /// Directory with canned profiles & SSM database
        /// </summary>
        /// <remarks>For test use only</remarks>
        /// <returns>Directory with canned profiles & SSM database</returns>
        internal static string GetConfigurationDirectory()
        {
            if (Lumberjack.configurationDirectory == null)
            {
                string assemblyPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                if (assemblyPath.Contains("TestResults"))
                {
                    string[] parts = assemblyPath.Split(Path.DirectorySeparatorChar);
                    assemblyPath = string.Join(Path.DirectorySeparatorChar.ToString(), parts, 0, parts.Length - 3);
                }
                assemblyPath = Path.GetDirectoryName(assemblyPath);
                Lumberjack.configurationDirectory = Path.Combine(assemblyPath, "Configuration");
            }
            return Lumberjack.configurationDirectory;
        }
    }
}
