///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// Lumberjack.Private.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.IO.Ports;
using System.Threading;
using NateW.Ssm.Applications.Properties;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Windows.Forms;

namespace NateW.Ssm.Applications
{
    public partial class Lumberjack
    {
        /// <summary>
        /// Prompt user to save profile if it has changed.
        /// </summary>
        /// <returns>False if the user doesn't want to save, otherwise true.</returns>
        private bool SaveProfileIfChanged()
        {
            if (this.currentProfileIsChanged)
            {
                if (!PromptToSaveChangedProfile())
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Load a logging profile from the given path.
        /// </summary>
        /// <param name="newProfilePath">Path to the desired profile.</param>
        private void LoadProfile(string newProfilePath)
        {
            if (string.IsNullOrEmpty(newProfilePath))
            {
                return;
            }

            this.logger.BeginStopLogging(ContinueLoadProfile, newProfilePath);
        }

        /// <summary>
        /// Second half of LoadProfile
        /// </summary>
        private void ContinueLoadProfile(IAsyncResult asyncResult)
        {
            string newProfilePath = (string)asyncResult.AsyncState;

            this.ui.Invoke(delegate
            {
                this.logger.LoadProfile(newProfilePath);
                this.Settings.LastProfilePath = newProfilePath;
                this.ignoreProfileSettingsChangeNotifications = true;
                this.ShowNewProfileSettings();
                this.ignoreProfileSettingsChangeNotifications = false;
                this.ui.SetSaveButtonState(true);
                this.ui.SetLogMode(LogMode.DisplayOnly);
                this.currentProfileIsChanged = false;
                this.SetTitle();
                this.logger.StartLogging();
            });
        }

        /// <summary>
        /// Save the list of known profiles, so that they may be reloaded next time.
        /// </summary>
        private void SaveProfileList()
        {
            StringCollection paths = this.Settings.RecentProfiles;
            if (paths == null)
            {
                paths = new StringCollection();
            }
            paths.Clear();

            foreach (PathDisplayAdaptor adaptor in this.ui.Profiles)
            {
                paths.Add(adaptor.Path);
            }

            this.Settings.RecentProfiles = paths;
            this.Settings.Save();
        }

        /// <summary>
        /// Initialize the list of available serial ports.
        /// </summary>
        private void InitializeSerialPortList()
        {
            this.ui.AddSerialPort(MockEcuPortName);
            foreach (string name in System.IO.Ports.SerialPort.GetPortNames())
            {
                this.ui.AddSerialPort(name);
            }

            string lastPort = this.Settings.DefaultPort;
            if (!this.ui.SerialPortListContains(lastPort))
            {
                lastPort = MockEcuPortName;
            }

            this.ui.SelectSerialPort(lastPort);
        }

        /// <summary>
        /// Initialize the list of known profiles.
        /// </summary>
        private void InitializeProfileList()
        {
            if (this.Settings.RecentProfiles != null)
            {
                foreach (string path in this.Settings.RecentProfiles)
                {
                    if (File.Exists(path))
                    {
                        this.ui.AddProfile(path);
                    }
                }
            }
        }

        /// <summary>
        /// Initialize the path to the log-file folder.
        /// </summary>
        private void InitializeLogFolderPath()
        {
            if (string.IsNullOrEmpty(this.Settings.LogFolderPath))
            {
                this.Settings.LogFolderPath = Environment.GetEnvironmentVariable("HOMEPATH");
            }
            this.ui.ShowLogFolder(this.Settings.LogFolderPath);
        }

        /// <summary>
        /// Update the UI to show the new profile.
        /// </summary>
        private void ShowNewProfileSettings()
        {
            bool changed = this.currentProfileIsChanged;
            this.ui.ShowNewProfileSettings(this.logger.CurrentProfile);
            this.currentProfileIsChanged = changed;
        }

        /// <summary>
        /// Set the main window title based on the current application state.
        /// </summary>
        private void SetTitle()
        {
            StringBuilder builder = new StringBuilder(100);
            builder.Append("Lumberjack");
            builder.Append(" - ");
            
            string selectedPort = this.ui.GetSelectedSerialPort();
            if (selectedPort != null)
            {
                builder.Append(selectedPort);
                builder.Append(" - ");
            }

            if (!string.IsNullOrEmpty(this.Settings.LastProfilePath))
            {
                builder.Append(new PathDisplayAdaptor(this.Settings.LastProfilePath).ToString());
            }
            else
            {
                builder.Append("new profile");
            }

            if (this.currentProfileIsChanged)
            {
                builder.Append('*');
            }
            string title = builder.ToString();
            this.ui.SetTitle(title);
        }

        /// <summary>
        /// Close an reopen the ECU interface.
        /// </summary>
        private void ReopenEcuInterface()
        {
            this.CloseEcuInterface();

            string portName = this.ui.GetSelectedSerialPort();
            if (!string.IsNullOrEmpty(portName))
            {
                this.OpenEcuInterface(portName);
            }
        }

        /// <summary>
        /// Close the ECU interface.
        /// </summary>
        private void CloseEcuInterface()
        {
            Trace("CloseEcuInterface");

            if (this.logger != null)
            {
                this.logger.BeginStopLogging(this.ContinueCloseEcuInterface, null);
                this.logger = null;
            }

            if (this.ecuStream != null)
            {
                this.ecuStream.Dispose();
                this.ecuStream = null;
            }

            if (this.port != null)
            {
                this.port.Dispose();
                this.port = null;
            }

            this.ui.ConnectionStateChanged(false);
        }

        /// <summary>
        /// No-op
        /// </summary>
        private void ContinueCloseEcuInterface(IAsyncResult asyncResult)
        {
        }

        /// <summary>
        /// Second half of the MainForm_Closing handler
        /// </summary>
        private void ContinueClosing(IAsyncResult asyncResult)
        {
            this.ui.Invoke(delegate { this.ui.Close(); });
        }

        /// <summary>
        /// Open the ECU interface.
        /// </summary>
        /// <param name="name">Name of the serial port to use for ECU communication.</param>
        private void OpenEcuInterface(string name)
        {
            Trace("OpenEcuInterface");

            if (name == MockEcuPortName)
            {
                this.ecuStream = MockEcuStream.CreateInstance();
            }
            else
            {
                this.port = new SerialPort(name, 4800, Parity.None, 8, StopBits.One);
                this.port.Open();
                this.port.ReadTimeout = 2000;
                this.ecuStream = this.port.BaseStream;
            }

            string configurationDirectory = Lumberjack.GetConfigurationDirectory();
            this.logger = SsmLogger.GetInstance(configurationDirectory, this.ecuStream);
            this.logger.LogStart += this.OnLogStart;
            this.logger.LogEntry += this.OnLogEntry;
            this.logger.LogStop += this.OnLogStop;
            this.logger.LogError += this.OnLogError;

            this.logger.BeginConnect(ConnectCallback, name);
        }

        /// <summary>
        /// Callback to be invoked when the ECU connection is established.
        /// </summary>
        /// <param name="asyncResult">Async result.</param>
        private void ConnectCallback(IAsyncResult asyncResult)
        {
            Trace("ConnectCallback");

            if (this.logger == null)
            {
                return;
            }

            try
            {
                this.logger.EndConnect(asyncResult);
            }
            catch (SsmPacketFormatException ex)
            {
                this.ui.Invoke(new ThreadStart(
                    delegate
                    {
                        this.ui.RenderError(ex);
                        this.ui.ConnectionStateChanged(false);
                    }));
                return;
            }

            try
            {
                this.ui.Invoke(new ThreadStart(
                delegate
                {
                    this.ui.PopulateParameterList(this.logger.Database);
                    this.ui.ConnectionStateChanged(true);

                    this.LoadSelectedProfile();

                    this.Settings.DefaultPort = (string)asyncResult.AsyncState;
                    this.currentProfileIsChanged = false;

                    if (this.startMode != LogMode.None)
                    {
                        this.ui.SetLogMode(this.startMode);
                        this.startMode = LogMode.None;
                    }
                }));
            }
            catch (IOException ex)
            {
                this.ui.Invoke(new ThreadStart(
                    delegate
                    {
                        this.ui.RenderError(ex);
                    }));
            }
        }

        /// <summary>
        /// Load the currently selected logging profile.
        /// </summary>
        private void LoadSelectedProfile()
        {
            if (this.currentProfileIsChanged)
            {
                string oldPath = new PathDisplayAdaptor(this.Settings.LastProfilePath).ToString();
                DialogResult dialogResult = this.ui.PromptToSaveProfileBeforeChanging(oldPath);

                if (dialogResult == DialogResult.Cancel)
                {
                    this.ui.SelectProfile(this.Settings.LastProfilePath);
                    return;
                }
                else if (dialogResult == DialogResult.Yes)
                {
                    this.logger.SaveProfile(this.Settings.LastProfilePath);
                }
            }

            string profilePath = this.ui.GetSelectedProfile();
            if (profilePath == null)
            {
                this.ui.SetSaveButtonState(false);
                return;
            }

            this.logger.BeginStopLogging(ContinueLoadSelectedProfile, profilePath);
        }

        /// <summary>
        /// Second half of LoadSelectedProfile
        /// </summary>
        private void ContinueLoadSelectedProfile(IAsyncResult asyncResult)
        {
            string profilePath = (string) asyncResult.AsyncState;

            this.ui.Invoke(delegate
            {
                this.logger.LoadProfile(profilePath);
                this.logger.StartLogging();
                this.Settings.LastProfilePath = profilePath;
                this.ui.ShowNewProfileSettings(this.logger.CurrentProfile);
                this.ui.SelectProfile(this.Settings.LastProfilePath);
                this.currentProfileIsChanged = false;
                this.ui.SetSaveButtonState(true);
                this.SetTitle();
            });
        }

        /// <summary>
        /// Prompt to save the profile.
        /// </summary>
        /// <remarks>
        /// Assumes that the profile has been checked for changes, and it has changed.
        /// </remarks>
        /// <returns>False if the user wants to cancel whatever lead to this.</returns>
        private bool PromptToSaveChangedProfile()
        {
            string oldPath = this.Settings.LastProfilePath.ToString();
            DialogResult saveResult = this.ui.PromptToSaveProfileBeforeChanging(oldPath);

            if (saveResult == DialogResult.Cancel)
            {
                return false;
            }
            else if (saveResult == DialogResult.Yes)
            {
                this.logger.SaveProfile(this.Settings.LastProfilePath);
            }

            return true;
        }

        /// <summary>
        /// Write a debugging trace message.
        /// </summary>
        /// <param name="message">Debug trace message.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        private void Trace(string message)
        {
            Debug.WriteLine(message);
        }
    }
}
