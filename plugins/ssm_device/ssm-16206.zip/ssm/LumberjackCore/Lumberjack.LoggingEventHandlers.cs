///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// Lumberjack.LoggingEventHandlers.cs
// SsmLogger callbacks
///////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.IO;
using System.IO.Ports;
using System.Threading;
using NateW.Ssm.Applications.Properties;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Windows.Forms;

namespace NateW.Ssm.Applications
{
    public partial class Lumberjack
    {
        /// <summary>
        /// Indicates whether the data should be logged
        /// </summary>
        /// <remarks>
        /// TODO: Cache a reference to the column that matters
        /// </remarks>
        /// <param name="row">a row of logger data</param>
        /// <returns>true if the data should be logged, false if not</returns>
        private bool ShouldLog(LogRow row)
        {
            string columnId = null;
            string requiredValue = null;

            if (this.logMode == LogMode.Constant)
            {
                return true;
            }
            else if (this.logMode == LogMode.DisplayOnly)
            {
                return false;
            }
            else if (this.logMode == LogMode.Defogger)
            {
                columnId = "S20";
                requiredValue = "True";
            }
            else if (this.logMode == LogMode.ClosedLoop)
            {
                columnId = "E27";
                requiredValue = "8";
            }
            else if (this.logMode == LogMode.OpenLoop)
            {
                columnId = "E27";
                requiredValue = "10";
            }
            else
            {
                Debug.Assert(false, "Unknown LogMode value in Lumberjack.ShouldLog(): " + this.logMode.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(columnId) || string.IsNullOrEmpty(requiredValue))
            {
                return false;
            }

            foreach (LogColumn column in row.Columns)
            {
                if (column.Parameter.Id == columnId)
                {
                    if (column.Value.Equals(requiredValue, StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// Does what it says
        /// </summary>
        /// <returns>you can probably guess</returns>
        private LogWriter CreateLogWriter()
        {
            this.logStartTime = DateTime.Now;
            string logFileName = this.logStartTime.ToString("yyyyMMdd-hhmmss", CultureInfo.InvariantCulture) + ".csv";
            string logFilePath = Path.Combine(Settings.Default.LogFolderPath, logFileName);
            Stream stream = File.OpenWrite(logFilePath);
            return LogWriter.GetInstance(stream, true);
        }

        /// <summary>
        /// Handles LogStart events from the SSM logger
        /// </summary>
        private void OnLogStart(object sender, LogEventArgs args)
        {
            Trace("LogStart");
            this.logFilter.LogStart(args.Row);
        }

        /// <summary>
        /// Handles LogEntry events from the SSM logger
        /// </summary>
        private void OnLogEntry(object sender, LogEventArgs args)
        {
            this.ui.Invoke(new ThreadStart(delegate
                       {
                           this.ui.RenderLogEntry(args);
                       }));

            this.logFilter.LogEntry(args.Row);
        }

        /// <summary>
        /// Handles LogStop events from the SSM logger
        /// </summary>
        private void OnLogStop(object sender, EventArgs args)
        {
            this.logFilter.LogStop();

            if (this.restartLogging)
            {
                this.restartLogging = false;
                this.logger.StartLogging();
            }
        }

        /// <summary>
        /// Handles LogError events from the SSM logger
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2201:DoNotRaiseReservedExceptionTypes"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        private void OnLogError(object sender, LogErrorEventArgs args)
        {
            Exception exception = args.Exception;
            try
            {
                if ((exception is SsmPacketFormatException) ||
                    (exception is IOException) ||
                    (exception is System.Security.SecurityException))
                {
                    this.ReopenEcuInterface();
                    return;
                }
            }
            catch (Exception outer)
            {
                exception = new Exception(outer.Message, exception);
            }                        

            this.ui.Invoke(new ThreadStart(delegate
            {
                this.ui.RenderError(exception);
            }));
        }
    }
}
