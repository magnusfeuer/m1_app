﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Lumberjack")]
[assembly: AssemblyDescription("Data logging utility for ISO9141 Subaru vehicles")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Nate Waddoups")]
[assembly: AssemblyProduct("Lumberjack")]
[assembly: AssemblyCopyright("Copyright ©  2007")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("23f1f97d-bd92-4260-93ce-2656583aea0a")]
