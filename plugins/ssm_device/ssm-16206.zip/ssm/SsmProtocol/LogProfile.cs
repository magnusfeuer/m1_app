///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// LogProfile.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace NateW.Ssm
{
    /// <summary>
    /// Holds parameters and their conversions 
    /// </summary>
    public class LogProfile
    {
        private Dictionary<SsmParameter, Conversion> dictionary;

        public ICollection<SsmParameter> Parameters
        {
            [DebuggerStepThrough()]
            get { return this.dictionary.Keys; }
        }

        private LogProfile()
        {
            this.dictionary = new Dictionary<SsmParameter, Conversion>();
        }

        public static LogProfile CreateInstance()
        {
            return new LogProfile();
        }

        public bool Contains(SsmParameter parameter)
        {
            return this.dictionary.ContainsKey(parameter);
        }

        public void Add(SsmParameter parameter, Conversion conversion)
        {
            this.dictionary[parameter] = conversion;        
        }

        public Conversion GetConversion(SsmParameter parameter)
        {
            return this.dictionary[parameter];
        }
    }

}
