///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// SsmInterface.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading;
using System.Security;

namespace NateW.Ssm
{
    /// <summary>
    /// Knows how to send and receive SSM packets, so the caller can invoke
    /// SSM operations without knowing anything about the SSM packet syntax.
    /// </summary>
    public class SsmInterface
    {
        /// <summary>
        /// Stream to use for communications with the ECU
        /// </summary>
        private Stream stream;

        /// <summary>
        /// This is used to guard against multiple simultaneous read/write operations
        /// </summary>
        private int outstandingQueries;

        /// <summary>
        /// The ECU's identifer
        /// </summary>
        private string ecuIdentifier;

        /// <summary>
        /// The ECU's identifier
        /// </summary>
        public string EcuIdentifier
        {
            [DebuggerStepThrough()]
            get { return this.ecuIdentifier; }
        }

        /// <summary>
        /// True if a read/write operation is in progress
        /// </summary>
        public bool OperationInProgress
        {
            get { return this.outstandingQueries != 0; }
        }

        /// <summary>
        /// Private constructor - use factory instead
        /// </summary>
        private SsmInterface(Stream stream)
        {
            this.stream = stream;
        }

        /// <summary>
        /// Factory
        /// </summary>
        public static SsmInterface GetInstance(Stream stream)
        {
            return new SsmInterface(stream);
        }

        #region GetEcuIdentifier

        /// <summary>
        /// Sends an ECU identifier request
        /// </summary>
        public IAsyncResult BeginGetEcuIdentifier(AsyncCallback callback, object state)
        {
            this.BeginOperation();

            GetEcuIdentifierAsyncResult internalState = new GetEcuIdentifierAsyncResult(callback, state);
            SsmPacket request = SsmPacket.CreateEcuIdentifierRequest();
            this.stream.BeginWrite(
                request.Data, 
                0, 
                request.Data.Length, 
                this.EcuIdentifierRequestWritten,
                internalState);
            return internalState;
        }

        /// <summary>
        /// Invoked after the ECU identifier request has been written - begins reading the response
        /// </summary>
        private void EcuIdentifierRequestWritten(IAsyncResult asyncResult)
        {
            GetEcuIdentifierAsyncResult internalState = (GetEcuIdentifierAsyncResult)asyncResult.AsyncState;
                
            try
            {
                this.stream.EndWrite(asyncResult);
                internalState.Parser.BeginReadFromStream(this.stream, EcuIdentifierResponseRead, internalState);
            }
            catch (IOException ex)
            {
                internalState.Exception = ex;
                internalState.Completed();
            }
            catch (SecurityException ex)
            {
                internalState.Exception = ex;
                internalState.Completed();
            }
        }

        /// <summary>
        /// Invoked after the ECU identifier response has been received
        /// </summary>
        private void EcuIdentifierResponseRead(IAsyncResult asyncResult)
        {
            GetEcuIdentifierAsyncResult internalState = (GetEcuIdentifierAsyncResult)asyncResult.AsyncState;

            try
            {
                SsmPacket response = internalState.Parser.EndReadFromStream(asyncResult);
                this.ecuIdentifier = response.EcuIdentifier;
            }
            catch (IOException ex)
            {
                internalState.Exception = ex;
            }
            catch (SecurityException ex)
            {
                internalState.Exception = ex;
            }
            catch (SsmPacketFormatException ex)
            {
                internalState.Exception = ex;
            }
            internalState.Completed();
        }

        /// <summary>
        /// Returns the ECU identifier to the caller
        /// </summary>
        public string EndGetEcuIdentifier(IAsyncResult asyncResult)
        {
            this.EndOperation();

            GetEcuIdentifierAsyncResult internalState = (GetEcuIdentifierAsyncResult)asyncResult;
            if (internalState.Exception != null)
            {
                throw internalState.Exception;
            }

            return this.EcuIdentifier;
        }

        #endregion

        #region MultipleRead

        /// <summary>
        /// Begins reading multiple disjoint addesses from the ECU
        /// </summary>
        public IAsyncResult BeginMultipleRead(IList<int> addresses, AsyncCallback callback, object state)
        {
            this.BeginOperation();

            MultipleReadAsyncResult internalState = new MultipleReadAsyncResult(callback, state);
            SsmPacket request = SsmPacket.CreateMultipleReadRequest(addresses);
            this.stream.BeginWrite(
                request.Data,
                0,
                request.Data.Length,
                this.MultipleReadRequestWritten,
                internalState);
            return internalState;
        }

        /// <summary>
        /// Invoked after the read request has been written to the ECU - begins waiting for the response
        /// </summary>
        private void MultipleReadRequestWritten(IAsyncResult asyncResult)
        {
            MultipleReadAsyncResult internalState = (MultipleReadAsyncResult)asyncResult.AsyncState;

            try
            {
                this.stream.EndWrite(asyncResult);
                internalState.Parser.BeginReadFromStream(
                    stream, 
                    MultipleReadResponseReceived, 
                    internalState);
            }
            catch (IOException ex)
            {
                internalState.Exception = ex;
                internalState.Completed();
            }
            catch (SecurityException ex)
            {
                internalState.Exception = ex;
                internalState.Completed();
            }
        }
        
        /// <summary>
        /// Invoked after the read response has been received from the ECU
        /// </summary>
        private void MultipleReadResponseReceived(IAsyncResult asyncResult)
        {
            MultipleReadAsyncResult internalState = (MultipleReadAsyncResult)asyncResult.AsyncState;

            try
            {
                SsmPacket response = internalState.Parser.EndReadFromStream(asyncResult);
                
                // Uncomment for easier debugging:                
                //byte[] data = response.Data;
                //SsmCommand command = response.Command;
                //int payloadLength = response.PayloadLength;
                //IList<byte> values = response.Values;

                foreach (byte value in response.Values)
                {
                    internalState.ValueList.Add(value);
                }
            }
            catch (IOException ex)
            {
                internalState.Exception = ex;
            }
            catch (SecurityException ex)
            {
                internalState.Exception = ex;
            }
            catch (SsmPacketFormatException ex)
            {
                internalState.Exception = ex;
            }
            internalState.Completed();
        }

        /// <summary>
        /// Returns the read results to the caller
        /// </summary>
        public byte[] EndMultipleRead(IAsyncResult asyncResult)
        {
            this.EndOperation();
            
            MultipleReadAsyncResult internalState = (MultipleReadAsyncResult)asyncResult;
            if (internalState.Exception != null)
            {
                throw internalState.Exception;
            }

            return internalState.Values;
        }

        #endregion

        /// <summary>
        /// Synchronously issues a read request and waits for the response - for testing only
        /// </summary>
        internal byte[] SyncReadMultiple(IList<int> addresses)
        {
            SsmPacket request = SsmPacket.CreateMultipleReadRequest(addresses);
            SsmPacket response = this.SyncGetResponse(request);
            return ((List<byte>)response.Values).ToArray();
        }

        /// <summary>
        /// Synchronously sends a request and waits for the response - only here to support testing
        /// </summary>
        private SsmPacket SyncGetResponse(SsmPacket request)
        {
            stream.Write(request.Data, 0, request.Data.Length);
            byte[] tempBuffer = new byte[2000];
            stream.Read(tempBuffer, 0, tempBuffer.Length);
            SsmPacket response = SsmPacket.ParseResponse(tempBuffer, 0, tempBuffer.Length);
            return response;
        }

        /// <summary>
        /// Invoke this to throw an InvalidOperationException when the consumer
        /// tries to invoke a new transaction before an existing transaction
        /// has finished.
        /// </summary>
        private void BeginOperation()
        {
            int result = Interlocked.Increment(ref this.outstandingQueries);
            if (result != 1)
            {
                throw new InvalidOperationException("Simultaneous operations attempted");
            }
        }

        /// <summary>
        /// Invoke when a read/write operation completes
        /// </summary>
        private void EndOperation()
        {
            int result = Interlocked.Decrement(ref this.outstandingQueries);
            if (result != 0)
            {
                throw new InvalidOperationException("No operation in progress now.");
            }
        }
    }
}
