///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// AsyncResult.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading;

namespace NateW.Ssm
{
    /// <summary>
    /// Base class for IAsyncResult implementation
    /// </summary>
    internal class AsyncResult : IAsyncResult
    {
        private object asyncState;
        private ManualResetEvent waitHandle;
        private Exception exception;
        private int completions;
        private AsyncCallback asyncCallback;
        
        /// <summary>
        /// Exception to be thrown from .EndWhatever()
        /// </summary>
        public Exception Exception
        {
            [DebuggerStepThrough()]
            set { this.exception = value; }

            [DebuggerStepThrough()]
            get { return this.exception; }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public AsyncResult(AsyncCallback asyncCallback, object asyncState)
        {
            this.asyncCallback = asyncCallback;
            this.asyncState = asyncState;
            this.waitHandle = new ManualResetEvent(false);
        }

        /// <summary>
        /// Invoke this when the async operation is completed
        /// </summary>
        public void Completed()
        {
            // First one wins, second and later are ignored
            if (Interlocked.CompareExchange(ref this.completions, 1, 0) == 1)
            {
                return;
            }

            if (this.asyncCallback != null)
            {
                this.asyncCallback(this);
            }

            ((ManualResetEvent)this.AsyncWaitHandle).Set();
        }

        #region IAsyncResult Members

        public object AsyncState
        {
            [DebuggerStepThrough()]
            get { return this.asyncState; }
        }

        public WaitHandle AsyncWaitHandle
        {
            [DebuggerStepThrough()]
            get { return this.waitHandle; }
        }

        public bool CompletedSynchronously
        {
            [DebuggerStepThrough()]
            get { return false; }
        }

        public bool IsCompleted
        {
            [DebuggerStepThrough()]
            get { return this.completions != 0; }
        }

        #endregion
    }
}
