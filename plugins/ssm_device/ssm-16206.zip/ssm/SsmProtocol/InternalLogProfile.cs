///////////////////////////////////////////////////////////////////////////////
// Copyright (c) Nate Waddoups
// InternalLogProfile.cs
///////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.Text;

namespace NateW.Ssm
{
    /// <summary>
    /// The mutable part of the logger type
    /// </summary>
    internal class InternalLogProfile
    {
        private LogProfile profile;
        private LogEventArgs logEventArgs;
        private List<int> addresses;
        private SsmParameterDatabase database;

        /// <summary>
        /// Public-facing LogProfile instance upon which this instance of InternalLogProfile was based
        /// </summary>
        public LogProfile LogProfile
        {
            [DebuggerStepThrough()]
            get { return this.profile; }
        }

        /// <summary>
        /// EventArgs to pass to the application
        /// </summary>
        public LogEventArgs LogEventArgs
        {
            [DebuggerStepThrough()]
            get { return this.logEventArgs; }
        }

        /// <summary>
        /// Addresses to query from the ECU
        /// </summary>
        public List<int> Addresses
        {
            [DebuggerStepThrough()]
            get { return this.addresses; }
        }

        /// <summary>
        /// Private constructor, use factory instead
        /// </summary>
        /// <param name="profile"></param>
        private InternalLogProfile(LogProfile profile, SsmParameterDatabase database)
        {
            this.profile = profile;
            this.database = database;

            List<LogColumn> columns = new List<LogColumn>();
            AddColumnsAndDependents(columns, this.profile);
            this.addresses = BuildAddressList(columns);

            ReadOnlyCollection<LogColumn> readOnly = columns.AsReadOnly();
            LogRow row = LogRow.GetInstance(readOnly);
            this.logEventArgs = new LogEventArgs(row);
        }

        /// <summary>
        /// Factory
        /// </summary>
        public static InternalLogProfile GetInstance(LogProfile profile, SsmParameterDatabase database)
        {
            return new InternalLogProfile(profile, database);
        }

        /// <summary>
        /// Convert raw bytes from the ECU to displayable parameters
        /// </summary>
        internal void StoreConvertedValues(byte[] rawData)
        {
            int index = 0;
            foreach (LogColumn column in this.logEventArgs.Row.Columns)
            {
                if (column.DependencyMap == null)
                {
                    column.Value = InternalLogProfile.GetConvertedValue(
                        column.Parameter,
                        column.Conversion,
                        rawData,
                        index);
                    index += column.Parameter.Length;
                }
                else
                {
                    column.Value = column.Conversion.Convert(column.DependencyMap);
                }
            }
        }

        /// <summary>
        /// Looks up the Conversion to use for the given parameter
        /// </summary>
        /// <param name="dependency">SsmParameter that some other parameter depends on</param>
        /// <param name="parentConversion">Conversion that the 'other' parameter uses</param>
        /// <param name="dependencyConversion">Conversion to use for the dependency</param>
        /// <param name="dependencyKey">This string identifies the dependency 
        /// ID and conversion, will be used later by the expression evaluator.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1309:UseOrdinalStringComparison", MessageId = "System.String.IndexOf(System.String,System.StringComparison)")]
        private static void GetDependencyConversion(
            SsmParameter dependency,
            Conversion parentConversion,
            out Conversion dependencyConversion,
            out string dependencyKey)
        {
            foreach (Conversion conversion in dependency.Conversions)
            {
                dependencyKey = dependency.Id + ":" + conversion.Units;
                if (parentConversion.Expression.IndexOf(dependencyKey, StringComparison.InvariantCultureIgnoreCase) != -1)
                {
                    dependencyConversion = conversion;
                    return;
                }
            }

            dependencyKey = dependency.Id;
            dependencyConversion = dependency.Conversions[0];
        }

        /// <summary>
        /// Build the list of addresses to query from the ECU
        /// </summary>
        private static List<int> BuildAddressList(IList<LogColumn> columns)
        {
            List<int> addresses = new List<int>();

            foreach (LogColumn column in columns)
            {
                if (!column.IsCalculated)
                {
                    int address = column.Parameter.Address;
                    addresses.Add(address);
                    for (int i = 1; i < column.Parameter.Length; i++)
                    {
                        addresses.Add(++address);
                    }
                }
            }

            return addresses;
        }

        /// <summary>
        /// Build the list of columns for the given profile
        /// </summary>
        private void AddColumnsAndDependents(IList<LogColumn> columns, LogProfile newProfile)
        {
            foreach (SsmParameter parameter in newProfile.Parameters)
            {
                Conversion conversion = newProfile.GetConversion(parameter);
                Dictionary<string, LogColumn> dependencyMap = null;

                if (parameter.IsCalculated)
                {
                    dependencyMap = new Dictionary<string, LogColumn>();

                    foreach (SsmParameter dependency in parameter.Dependencies)
                    {
                        string depencencyKey;
                        Conversion dependencyConversion;

                        GetDependencyConversion(
                             dependency,
                             conversion,
                             out dependencyConversion,
                             out depencencyKey);

                        LogColumn dependencyColumn = AddColumn(
                            columns,
                            dependency,
                            dependencyConversion,
                            true);

                        dependencyMap[depencencyKey] = dependencyColumn;
                    }
                }

                LogColumn column = this.AddColumn(
                    columns,
                    parameter,
                    conversion,
                    false);

                column.DependencyMap = dependencyMap;
            }
        }

        /// <summary>
        /// Adds a column to the list of columns to be logged
        /// </summary>
        private LogColumn AddColumn(
            IList<LogColumn> columns,
            SsmParameter parameter,
            Conversion conversion,
            bool isDependency)
        {
            if (!this.database.Parameters.Contains(parameter))
            {
                throw new ArgumentException(
                    string.Format(
                        CultureInfo.InvariantCulture,
                        "This ECU (ID: {0}) does not support the \"{1}\" parameter",
                        this.database.EcuIdentifier,
                        parameter.Name));
            }
            
            LogColumn column = LogColumn.GetInstance(
                parameter,
                conversion,
                isDependency);

            columns.Add(column);
            return column;
        }

        /// <summary>
        /// Convert a parameter's raw bytes to a displayable string
        /// </summary>
        /// <param name="parameter">the parameter in question</param>
        /// <param name="conversion">the conversion to apply</param>
        /// <param name="rawData">buffer holding all of the bytes recievd from the ECU (for all parameters)</param>
        /// <param name="index">index to begin reading from the buffer</param>
        /// <returns>converted and formatted value in string form</returns>
        private static string GetConvertedValue(
            SsmParameter parameter,
            Conversion conversion,
            byte[] rawData,
            int index)
        {
            string result = string.Empty;

            if (parameter.Length == 1)
            {
                byte b = rawData[index];
                result = conversion.Convert((double)b);
            }
            else if (parameter.Length == 2)
            {
                UInt16 u = rawData[index];// BitConverter.ToInt16(rawData, index);
                u <<= 8;
                u |= rawData[index + 1];
                result = conversion.Convert((double)u);
            }
            else if (parameter.Length == 4)
            {
                UInt32 l = rawData[index++];
                l <<= 8;
                l |= rawData[index++];
                l <<= 8;
                l |= rawData[index++];
                l <<= 8;
                l |= rawData[index++];
                double d;
                unsafe
                {
                    d = *((float*)&l);
                }
                result = conversion.Convert(d);
            }

            return result;
        }
    }
}
